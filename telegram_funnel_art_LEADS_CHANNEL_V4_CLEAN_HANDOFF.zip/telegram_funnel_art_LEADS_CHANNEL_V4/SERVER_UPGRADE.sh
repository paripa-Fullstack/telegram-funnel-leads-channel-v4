#!/usr/bin/env bash
set -euo pipefail

NEW_DIR="$(cd "$(dirname "$0")" && pwd)"

# Prefer the currently deployed release, then older compatible releases.
if [ -n "${OLD_RELEASE_DIR:-}" ]; then
  OLD_DIR="$OLD_RELEASE_DIR"
elif [ -d /opt/hrbot/telegram_funnel_art_FINAL_EDITABLE_V3 ]; then
  OLD_DIR=/opt/hrbot/telegram_funnel_art_FINAL_EDITABLE_V3
elif [ -d /opt/hrbot/telegram_funnel_art_FINAL_TZ_1TO1 ]; then
  OLD_DIR=/opt/hrbot/telegram_funnel_art_FINAL_TZ_1TO1
elif [ -d /opt/hrbot/telegram_funnel_art_WOW_FUNNEL_V2 ]; then
  OLD_DIR=/opt/hrbot/telegram_funnel_art_WOW_FUNNEL_V2
elif [ -d /opt/hrbot/telegram_funnel_art_FINAL_TEST_READY ]; then
  OLD_DIR=/opt/hrbot/telegram_funnel_art_FINAL_TEST_READY
else
  OLD_DIR=""
fi

echo "== Вселенная кадров / LEADS + CHANNEL V4 upgrade =="
echo "New: $NEW_DIR"
echo "Old: $OLD_DIR"

mkdir -p "$NEW_DIR/data" "$NEW_DIR/secrets"

if [ -d "$OLD_DIR" ] && [ "$OLD_DIR" != "$NEW_DIR" ]; then
  echo "[1/5] Stopping previous HR bot only..."
  (cd "$OLD_DIR" && docker compose down) || true

  echo "[2/5] Preserving production .env and SQLite data..."
  if [ -f "$OLD_DIR/.env" ]; then
    cp -a "$NEW_DIR/.env" "$NEW_DIR/.env.release-default" 2>/dev/null || true
    cp -a "$OLD_DIR/.env" "$NEW_DIR/.env"
  fi
  if [ -d "$OLD_DIR/data" ]; then
    cp -a "$OLD_DIR/data/." "$NEW_DIR/data/"
  fi
else
  echo "[1/5] Previous HR release not found; fresh install mode."
fi

# Add new keys without exposing/changing existing secrets.
ensure_key() {
  local key="$1" value="$2"
  if ! grep -q "^${key}=" "$NEW_DIR/.env" 2>/dev/null; then
    printf '\n%s=%s\n' "$key" "$value" >> "$NEW_DIR/.env"
  fi
}
ensure_key PRIVACY_POLICY_URL ""
ensure_key MATERIALS_FOLDER_URL ""
ensure_key WORK_CHAT_ID ""
ensure_key PUBLIC_BASE_URL ""
ensure_key COMMUNITY_CHANNEL_URL ""
ensure_key SUBSCRIPTION_NUDGE_MINUTES "30"

# For exact one-tap materials tracking, use this server's public IP when no URL was configured.
# The same container already publishes port 8080; admins may later replace this with an HTTPS domain.
CURRENT_BASE="$(grep '^PUBLIC_BASE_URL=' "$NEW_DIR/.env" | tail -1 | cut -d= -f2- || true)"
if [ -z "$CURRENT_BASE" ]; then
  IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
  if [ -n "$IP" ]; then
    sed -i "s#^PUBLIC_BASE_URL=.*#PUBLIC_BASE_URL=http://${IP}:8080#" "$NEW_DIR/.env"
    echo "[3/5] PUBLIC_BASE_URL auto-set to http://${IP}:8080 for one-tap tracked materials."
  else
    echo "[3/5] Could not detect public IP. Bot will use safe two-tap materials fallback."
  fi
else
  echo "[3/5] Keeping existing PUBLIC_BASE_URL=$CURRENT_BASE"
fi

chmod 600 "$NEW_DIR/.env" 2>/dev/null || true

echo "[4/5] Building and starting LEADS + CHANNEL V4..."
cd "$NEW_DIR"
docker compose up -d --build

echo "[5/5] Status..."
docker compose ps
sleep 4
docker compose logs --tail=100

echo
echo "Upgrade finished. Run: ./SELF_TEST_SERVER.sh"
echo "Then open /admin -> Корректировать воронку. Channel promo is non-blocking and defaults to the existing REQUIRED_CHANNEL settings."
