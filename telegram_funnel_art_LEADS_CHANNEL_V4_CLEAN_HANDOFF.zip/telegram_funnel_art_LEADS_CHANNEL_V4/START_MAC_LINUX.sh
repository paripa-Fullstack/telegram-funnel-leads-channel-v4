#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "========================================"
echo "  Telegram Funnel Art — WOW FUNNEL V2"
echo "========================================"
docker compose up --build
