# Обновление BestHost через SFTP

1. Загрузить архив `telegram_funnel_art_FINAL_EDITABLE_V3.zip` в `/opt/hrbot`.
2. В Termius выполнить:

```bash
cd /opt/hrbot
unzip telegram_funnel_art_FINAL_EDITABLE_V3.zip
cd telegram_funnel_art_FINAL_EDITABLE_V3
./SERVER_UPGRADE.sh
./SELF_TEST_SERVER.sh
docker compose ps
docker compose logs --tail=100
```

Ожидается:
- контейнер `healthy`;
- `Release: FINAL_EDITABLE_V3`;
- `Google Sheets: READY`;
- `Automation engine: READY`;
- `FINAL EDITABLE V3 STATIC AUDIT: OK`;
- `FINAL EDITABLE V3 SELF-TEST: OK`.

После обновления: `/admin` → `👤 Тест воронки глазами клиента` и `🛠 Корректировать воронку`.
