# Соответствие итоговому ТЗ

| Пункт ТЗ | Реализация |
|---|---|
| 1–2. Вход + source/Telegram ID/username/name/time | `handlers.py` + `Repo.upsert_lead`, first-touch source сохраняется |
| 3. ПД до приветствия, кнопка «Подтверждаю» | `consent_keyboard` + `consent_confirm` |
| 4. Кругляш + неизменный текст + 2 кнопки | `welcome_video_note_file_id` + `texts.WELCOME` + `main_menu_keyboard` |
| 5. Материалы -> папка, фиксировать первый клик | signed `/materials/...` redirect + `record_material_click` |
| 6. +4 часа от клика | `consult_offer_4h` + точный `CONSULT_OFFER_4H` |
| 7. +24 часа от первоначального клика | `manager_alert_24h`, только `notify_work_chat` |
| 8–9. Общая ветка консультации + уведомление команды | callback `consult` -> `record_consultation_request` |
| 10. +2 дня от входа, 7 вариантов | `problem_question_48h` + `PROBLEM_OPTIONS` |
| 11. Уведомление об ответе | `problem_answer` -> `notify_work_chat` |
| 12. +1 день от отправки вопроса | `question_event.created_at` -> `case_after_question_24h` |
| 13. Независимые ветки | URL materials + callback consult доступны одновременно |
| 14. Стоп повторных CTA после консультации | `SELLING_TOUCH_KEYS`; diagnostic +2d не отменяется |
| 15. Служебные уведомления только рабочий чат | `workchat.py`, отсутствует DM fallback |
| 16. Аналитика | события в SQLite + Apps Script/Google Sheets |
| 17. Точные точки отсчёта | first material event, original lead.created_at, actual question event time |

## Единственный контент, которого нет в исходном ТЗ

Финальный текст кейса для пункта 12 в документе прямо указан как «добавить отдельно после согласования контента». Сборка намеренно **не придумывает** этот текст. Администратор вставляет его через `/admin` -> `Настройки ТЗ` -> `Текст кейса (+1 день)`.
