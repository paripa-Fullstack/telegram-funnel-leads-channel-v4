# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from html import escape
from urllib.parse import urlparse

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.bot import texts
from app.bot.keyboards import (
    admin_home_keyboard,
    back_home_keyboard,
    button_admin_keyboard,
    button_screen_keyboard,
    buttons_admin_keyboard,
    campaign_admin_keyboard,
    campaign_delete_keyboard,
    campaign_material_keyboard,
    campaigns_admin_keyboard,
    material_admin_keyboard,
    material_delete_keyboard,
    materials_keyboard,
    settings_admin_keyboard,
    texts_admin_keyboard,
    primary_button_labels_keyboard,
    problem_options_admin_keyboard,
)
from app.config import Settings
from app.db.models import Material
from app.db.repo import MAX_ACTIVE_MATERIALS, Repo
from app.services.access import is_admin
from app.services.channel_promo import nudge_minutes, resolve_promo_channel
from app.services.analytics import Analytics
from app.services.sheets import SheetsMirror
from app.services.templating import render_text
from app.services.tracking import validate_campaign_code
from app.services.material_link import make_materials_tracking_url
from app.services.subscription import check_channel_subscription
from app.services.workchat import notify_work_chat

router = Router(name="admin")


class AdminWrite(StatesGroup):
    waiting_text = State()


class MaterialAdd(StatesGroup):
    title = State()
    description = State()
    asset = State()
    button_text = State()


class MaterialBulkLinks(StatesGroup):
    value = State()


class ButtonAdd(StatesGroup):
    label = State()
    url = State()


class TextEdit(StatesGroup):
    value = State()


class SettingEdit(StatesGroup):
    value = State()


class WelcomeMediaEdit(StatesGroup):
    asset = State()


class CampaignAdd(StatesGroup):
    code = State()
    channel = State()
    source = State()
    campaign = State()
    content = State()


TEXT_DEFAULTS = {
    "consent_intro": "Перед продолжением ознакомьтесь с Политикой обработки персональных данных и подтвердите согласие.",
    "welcome": texts.WELCOME,
    "consult_requested": texts.CONSULT_REQUESTED,
    "consult_offer_4h": texts.CONSULT_OFFER_4H,
    "problem_question": texts.PROBLEM_QUESTION,
    "subscription_nudge": "Кстати, у нас есть рабочий канал про найм и управление командой. Там регулярно выходят практические разборы и материалы — присоединяйтесь 👇",
}

TEXT_LABELS = {
    "consent_intro": "Текст перед согласием на обработку ПД",
    "welcome": "Приветственное сообщение после кружочка",
    "consult_requested": "Сообщение после заявки на консультацию",
    "consult_offer_4h": "Предложение консультации через 4 часа",
    "problem_question": "Вопрос через 2 дня от входа",
    "subscription_nudge": "Мягкое напоминание подписаться на канал",
}


PROBLEM_SETTING_PREFIX = "problem_label_"


SCREEN_LABELS = {
    "welcome": "Под приветственным сообщением",
    "material": "Старый экран материалов",
    "qualified": "Старый экран после квалификации",
}


def pct(value: int, base: int) -> str:
    return "0%" if base == 0 else f"{value / base * 100:.1f}%"


def _valid_url(value: str) -> bool:
    try:
        parsed = urlparse(value.strip())
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)
    except Exception:
        return False


def _is_enabled(value: str) -> bool:
    return str(value).strip().lower() not in {"0", "false", "off", "нет", "no"}


async def _allowed(user_id: int, settings: Settings, sessions: async_sessionmaker) -> bool:
    return await is_admin(user_id, settings, sessions)


async def _stats_text(sessions: async_sessionmaker) -> str:
    async with sessions() as session:
        data = await Repo(session).stats()
    leads = data["leads"]
    consented = data["consented"]
    material = data["material"]
    qualified = data["qualified"]
    requested = data["consultation_requested"]
    consulted = data["consultation"]
    deals = data["deal"]
    return (
        "<b>📊 Воронка сейчас</b>\n\n"
        f"🖱 Клики: <b>{data['clicks']}</b>\n"
        f"👥 Входы в бот: <b>{leads}</b>\n"
        f"✅ Дали согласие: <b>{consented}</b> · {pct(consented, leads)}\n"
        f"🎁 Получили материалы: <b>{material}</b> · {pct(material, consented or leads)}\n"
        f"🎯 Обозначили задачу: <b>{qualified}</b> · {pct(qualified, material)}\n"
        f"📅 Запрос консультации: <b>{requested}</b> · {pct(requested, material)}\n"
        f"🤝 Консультация: <b>{consulted}</b> · {pct(consulted, requested)}\n"
        f"💰 Сделка: <b>{deals}</b> · {pct(deals, consulted)}\n"
        f"✖️ Отказы: {data['lost']}"
    )


async def _material_card(item: Material) -> str:
    status = "активен" if item.is_active else "выключен"
    primary = " · ⭐ показывается первым" if item.is_primary else ""
    asset = {
        "document": f"Telegram-файл: {item.file_name or 'документ'}",
        "url": f"Ссылка: {item.url or '—'}",
        "none": "Без вложения",
    }.get(item.kind, item.kind)
    return (
        f"<b>📦 {escape(item.title)}</b>\n"
        f"Статус: <b>{status}</b>{primary}\n"
        f"Тип: {escape(asset)}\n\n"
        f"{escape(item.description or 'Описание не задано')}"
    )


# ------------------------ Admin entry ---------------------------------
@router.message(Command("admin"))
async def admin_home(message: Message, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    await message.answer(
        "<b>⚡ Панель управления воронкой</b>\n\n"
        "Материалы, тексты, быстрые скрипты МOП, рекламные источники и автоворонка — всё меняется без кода.",
        reply_markup=admin_home_keyboard(),
    )


@router.callback_query(F.data == "panel:home")
async def panel_home(callback: CallbackQuery, state: FSMContext, settings: Settings,
                     sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        await callback.answer("Недоступно", show_alert=True)
        return
    await state.clear()
    await callback.message.answer("<b>⚡ Панель управления воронкой</b>\n\nВыберите раздел:", reply_markup=admin_home_keyboard())
    await callback.answer()


@router.message(Command("whoami"))
async def whoami(message: Message) -> None:
    await message.answer(f"Ваш Telegram ID: <code>{message.from_user.id}</code>")


@router.message(Command("cancel"))
async def cancel_any_admin_state(message: Message, state: FSMContext, settings: Settings,
                                 sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    await state.clear()
    await message.answer("Отменено.", reply_markup=admin_home_keyboard())


# ------------------------ Materials -----------------------------------
@router.callback_query(F.data == "panel:materials")
async def panel_materials(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        repo = Repo(session)
        items = await repo.materials()
        active_count = await repo.active_material_count()
    text = (
        f"<b>📦 Материалы · активных {active_count}/{MAX_ACTIVE_MATERIALS}</b>\n\n"
        "Все активные материалы показываются пользователю одновременно. ⭐ — первый в списке."
    )
    if not items:
        text += "\n\nДобавьте до 6 ссылок или файлов."
    await callback.message.answer(text, reply_markup=materials_keyboard(items))
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:material:\d+$"))
async def panel_material(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    material_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        item = await Repo(session).get_material(material_id)
    if not item:
        await callback.answer("Материал не найден", show_alert=True)
        return
    await callback.message.answer(await _material_card(item), reply_markup=material_admin_keyboard(item))
    await callback.answer()


@router.callback_query(F.data == "panel:material_bulk_links")
async def material_bulk_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                              sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        active = await Repo(session).active_material_count()
    available = MAX_ACTIVE_MATERIALS - active
    if available <= 0:
        await callback.answer("Уже активны 6 материалов. Выключите или удалите один.", show_alert=True)
        return
    await state.clear()
    await state.set_state(MaterialBulkLinks.value)
    await callback.message.answer(
        f"<b>🔗 Быстрое добавление · свободно мест: {available}</b>\n\n"
        "Отправьте ссылки одним сообщением, каждая с новой строки:\n"
        "<code>Чек-лист вакансии | https://...</code>\n"
        "<code>Шаблон оффера | https://...</code>\n\n"
        f"Можно добавить максимум {available} сейчас. /cancel — отмена"
    )
    await callback.answer()


@router.message(MaterialBulkLinks.value)
async def material_bulk_finish(message: Message, state: FSMContext, settings: Settings,
                               sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    if not message.text:
        await message.answer("Нужен текст со ссылками.")
        return
    parsed: list[tuple[str, str]] = []
    for raw in message.text.splitlines():
        raw = raw.strip()
        if not raw:
            continue
        title, sep, url = raw.partition("|")
        if not sep or not title.strip() or not _valid_url(url.strip()):
            await message.answer(f"Не понял строку: <code>{escape(raw[:250])}</code>\nФормат: Название | https://...")
            return
        parsed.append((title.strip()[:256], url.strip()))
    if not parsed:
        await message.answer("Не нашёл ни одной ссылки.")
        return
    async with sessions() as session:
        repo = Repo(session)
        available = MAX_ACTIVE_MATERIALS - await repo.active_material_count()
        if len(parsed) > available:
            await message.answer(f"Сейчас можно добавить только {available}. Уменьшите список.")
            return
        created = []
        for title, url in parsed:
            created.append(await repo.create_material(title=title, kind="url", url=url, button_text=f"📘 {title[:60]}"))
        await session.commit()
    await state.clear()
    await message.answer(f"✅ Добавлено ссылок: <b>{len(created)}</b>. Они уже видны пользователям.", reply_markup=back_home_keyboard())


@router.callback_query(F.data == "panel:material_add")
async def material_add_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                             sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        if await Repo(session).active_material_count() >= MAX_ACTIVE_MATERIALS:
            await callback.answer("Уже активны 6 материалов. Выключите или удалите один.", show_alert=True)
            return
    await state.clear()
    await state.set_state(MaterialAdd.title)
    await callback.message.answer("<b>Новый материал · 1/4</b>\n\nВведите название.\n\n/cancel — отмена")
    await callback.answer()


@router.message(MaterialAdd.title)
async def material_add_title(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip():
        await message.answer("Нужно текстовое название.")
        return
    await state.update_data(title=message.text.strip()[:256])
    await state.set_state(MaterialAdd.description)
    await message.answer("<b>2/4</b> Короткое описание. Если не нужно — <code>-</code>.")


@router.message(MaterialAdd.description)
async def material_add_description(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("Отправьте текст или <code>-</code>.")
        return
    value = "" if message.text.strip() == "-" else message.text.strip()[:3000]
    await state.update_data(description=value)
    await state.set_state(MaterialAdd.asset)
    await message.answer(
        "<b>3/4</b> Сам материал:\n"
        "• отправьте PDF/документ;\n"
        "• пришлите http/https-ссылку;\n"
        "• или <code>-</code>."
    )


@router.message(MaterialAdd.asset)
async def material_add_asset(message: Message, state: FSMContext) -> None:
    if message.document:
        await state.update_data(kind="document", telegram_file_id=message.document.file_id,
                                file_name=message.document.file_name or "document", url="")
    elif message.text and message.text.strip() == "-":
        await state.update_data(kind="none", telegram_file_id="", file_name="", url="")
    elif message.text and _valid_url(message.text):
        await state.update_data(kind="url", telegram_file_id="", file_name="", url=message.text.strip())
    else:
        await message.answer("Не распознал. Пришлите документ, ссылку или <code>-</code>.")
        return
    await state.set_state(MaterialAdd.button_text)
    await message.answer("<b>4/4</b> Текст кнопки. Например <code>📘 Открыть чек-лист</code>. Для стандартного — <code>-</code>.")


@router.message(MaterialAdd.button_text)
async def material_add_finish(message: Message, state: FSMContext, settings: Settings,
                              sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    if not message.text:
        return
    data = await state.get_data()
    button_text = "📘 Открыть материал" if message.text.strip() == "-" else message.text.strip()[:128]
    try:
        async with sessions() as session:
            item = await Repo(session).create_material(
                title=data["title"], description=data.get("description", ""), kind=data.get("kind", "none"),
                url=data.get("url", ""), telegram_file_id=data.get("telegram_file_id", ""),
                file_name=data.get("file_name", ""), button_text=button_text,
            )
            await session.commit()
    except ValueError as exc:
        await state.clear()
        await message.answer(f"⚠️ {escape(str(exc))}", reply_markup=back_home_keyboard())
        return
    await state.clear()
    await message.answer("✅ <b>Материал добавлен.</b>\n\n" + await _material_card(item), reply_markup=material_admin_keyboard(item))


@router.callback_query(F.data.regexp(r"^panel:material_preview:\d+$"))
async def material_preview(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    material_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        item = await Repo(session).get_material(material_id)
    if not item:
        await callback.answer("Материал не найден", show_alert=True)
        return
    caption = f"<b>{escape(item.title)}</b>"
    if item.description:
        caption += f"\n\n{escape(item.description)}"
    if item.kind == "document" and item.telegram_file_id:
        await callback.message.answer_document(item.telegram_file_id, caption=caption[:1024])
    elif item.kind == "url" and item.url:
        await callback.message.answer(f"{caption}\n\n{escape(item.url)}")
    else:
        await callback.message.answer(caption)
    await callback.answer("Предпросмотр")


@router.callback_query(F.data.regexp(r"^panel:material_primary:\d+$"))
async def material_primary(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    material_id = int(callback.data.rsplit(":", 1)[1])
    try:
        async with sessions() as session:
            item = await Repo(session).set_primary_material(material_id)
            await session.commit()
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await callback.answer("⭐ Теперь показывается первым")
    if item:
        await callback.message.answer(await _material_card(item), reply_markup=material_admin_keyboard(item))


@router.callback_query(F.data.regexp(r"^panel:material_toggle:\d+$"))
async def material_toggle(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    material_id = int(callback.data.rsplit(":", 1)[1])
    try:
        async with sessions() as session:
            item = await Repo(session).toggle_material(material_id)
            await session.commit()
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    if not item:
        await callback.answer("Не найден", show_alert=True)
        return
    await callback.message.answer(await _material_card(item), reply_markup=material_admin_keyboard(item))
    await callback.answer("Сохранено")


@router.callback_query(F.data.regexp(r"^panel:material_delete_ask:\d+$"))
async def material_delete_ask(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    material_id = int(callback.data.rsplit(":", 1)[1])
    await callback.message.answer("Удалить материал окончательно?", reply_markup=material_delete_keyboard(material_id))
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:material_delete:\d+$"))
async def material_delete(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    material_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        repo = Repo(session)
        ok = await repo.delete_material(material_id)
        await session.commit()
        items = await repo.materials()
    await callback.answer("Удалено" if ok else "Не найдено", show_alert=not ok)
    await callback.message.answer("<b>📦 Материалы</b>", reply_markup=materials_keyboard(items))


# ------------------------ Buttons -------------------------------------
@router.callback_query(F.data == "panel:buttons")
async def panel_buttons(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        items = await Repo(session).buttons()
    text = (
        "<b>🧩 Дополнительные кнопки</b>\n\n"
        "Здесь можно добавлять свои URL-кнопки под приветственным сообщением: сайт, канал, кейсы, документы и т.д. "
        "Их можно включать, выключать и удалять без программиста."
    )
    await callback.message.answer(text, reply_markup=buttons_admin_keyboard(items))
    await callback.answer()


@router.callback_query(F.data == "panel:button_add")
async def button_add_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                           sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await state.clear()
    await callback.message.answer("Где показывать кнопку?", reply_markup=button_screen_keyboard())
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:button_screen:(welcome|material|qualified)$"))
async def button_add_screen(callback: CallbackQuery, state: FSMContext, settings: Settings,
                            sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    screen = callback.data.rsplit(":", 1)[1]
    await state.update_data(screen=screen)
    await state.set_state(ButtonAdd.label)
    await callback.message.answer(f"Экран: <b>{SCREEN_LABELS[screen]}</b>\n\nВведите текст кнопки.")
    await callback.answer()


@router.message(ButtonAdd.label)
async def button_add_label(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip():
        return
    await state.update_data(label=message.text.strip()[:128])
    await state.set_state(ButtonAdd.url)
    await message.answer("Теперь пришлите http/https-ссылку.")


@router.message(ButtonAdd.url)
async def button_add_url(message: Message, state: FSMContext, settings: Settings,
                         sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    if not message.text or not _valid_url(message.text):
        await message.answer("Нужна корректная ссылка.")
        return
    data = await state.get_data()
    async with sessions() as session:
        item = await Repo(session).create_button(screen=data["screen"], label=data["label"], url=message.text.strip())
        await session.commit()
    await state.clear()
    await message.answer(f"✅ Кнопка создана: <b>{escape(item.label)}</b>", reply_markup=button_admin_keyboard(item.id, item.is_active))


@router.callback_query(F.data.regexp(r"^panel:button:\d+$"))
async def panel_button(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    button_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        item = await Repo(session).get_button(button_id)
    if not item:
        await callback.answer("Не найдено", show_alert=True)
        return
    await callback.message.answer(
        f"<b>🧩 {escape(item.label)}</b>\n\nЭкран: {escape(SCREEN_LABELS.get(item.screen, item.screen))}\n"
        f"Статус: {'активна' if item.is_active else 'выключена'}\nURL: {escape(item.url)}",
        reply_markup=button_admin_keyboard(item.id, item.is_active),
    )
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:button_toggle:\d+$"))
async def button_toggle(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    button_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        item = await Repo(session).toggle_button(button_id)
        await session.commit()
    await callback.answer("Сохранено")
    if item:
        await callback.message.answer(f"<b>{escape(item.label)}</b> · {'активна' if item.is_active else 'выключена'}", reply_markup=button_admin_keyboard(item.id, item.is_active))


@router.callback_query(F.data.regexp(r"^panel:button_delete:\d+$"))
async def button_delete(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    button_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        repo = Repo(session)
        ok = await repo.delete_button(button_id)
        await session.commit()
        items = await repo.buttons()
    await callback.answer("Удалено" if ok else "Не найдено", show_alert=not ok)
    await callback.message.answer("<b>🧩 Кнопки</b>", reply_markup=buttons_admin_keyboard(items))


# ------------------------ Texts ---------------------------------------
@router.callback_query(F.data == "panel:texts")
async def panel_texts(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await callback.message.answer(
        "<b>✍️ Тексты воронки</b>\n\nВсе изменения применяются сразу. По умолчанию стоят тексты из финального ТЗ.",
        reply_markup=texts_admin_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("panel:text:"))
async def text_edit_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                          sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    key = callback.data.rsplit(":", 1)[1]
    if key not in TEXT_DEFAULTS:
        await callback.answer("Неизвестный текст", show_alert=True)
        return
    async with sessions() as session:
        current = await Repo(session).get_text(key, TEXT_DEFAULTS[key])
    await state.update_data(text_key=key)
    await state.set_state(TextEdit.value)
    await callback.message.answer(
        f"<b>{escape(TEXT_LABELS[key])}</b>\n\nСейчас:\n{current}\n\n"
        "Отправьте новый текст одним сообщением. Поддерживается Telegram HTML.\n"
        "Чтобы вернуть текст из ТЗ — отправьте <code>-</code>.\n/cancel — отмена"
    )
    await callback.answer()


@router.message(TextEdit.value)
async def text_edit_finish(message: Message, state: FSMContext, settings: Settings,
                           sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    if not message.text or not message.text.strip():
        return
    data = await state.get_data()
    value = message.text.strip()
    if value == "-":
        value = TEXT_DEFAULTS[data["text_key"]]
    async with sessions() as session:
        await Repo(session).set_text(data["text_key"], value)
        await session.commit()
    await state.clear()
    await message.answer("✅ Текст сохранён и уже используется ботом.", reply_markup=back_home_keyboard())


# ------------------------ Settings ------------------------------------
@router.callback_query(F.data == "panel:settings")
async def panel_settings(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        repo = Repo(session)
        policy = await repo.get_setting("privacy_policy_url", settings.privacy_policy_url or settings.legal_docs_url)
        policy_ok = bool(policy and _valid_url(policy))
        materials = await repo.get_setting("materials_folder_url", settings.materials_folder_url or settings.lead_magnet_url)
        work_chat = await repo.get_setting("work_chat_id", settings.work_chat_id)
        _community_channel, community_url = await resolve_promo_channel(repo, settings)
        sub_minutes = await nudge_minutes(repo, settings)
        note = await repo.get_setting("welcome_video_note_file_id", "")
        if not note and await repo.get_setting("welcome_media_kind", "") == "video_note":
            note = await repo.get_setting("welcome_media_file_id", "")
        case_text = await repo.get_setting("case_text", texts.CASE_DEFAULT)
    await callback.message.answer(
        "<b>⚙️ Настройки итогового ТЗ</b>\n\n"
        f"📄 Политика ПД: <b>{'настроена' if policy_ok else ('НЕКОРРЕКТНАЯ ССЫЛКА' if policy else 'НЕ настроена')}</b>\n"
        + (f"<code>{escape(policy)}</code>\n" if policy else "")
        + f"📁 Папка материалов: <b>{'настроена' if materials else 'НЕ настроена'}</b>\n"
        f"📣 Канал для подписки: <code>{escape(community_url or 'НЕ настроен')}</code>\n"
        f"⏱ Напоминание о канале: <b>{sub_minutes} мин</b>{' (выключено)' if sub_minutes == 0 else ''}\n"
        f"💬 Рабочий чат команды: <code>{escape(work_chat or 'НЕ настроен')}</code>\n"
        f"🎥 Приветственный кружок: <b>{'загружен' if note else 'НЕ загружен'}</b>\n"
        f"🧾 Кейс +1 день: <b>{'настроен' if case_text.strip() else 'НУЖЕН ТЕКСТ'}</b>\n\n"
        "Все основные тексты, кнопки и мягкое приглашение в канал можно менять без программиста.",
        reply_markup=settings_admin_keyboard(has_video_note=bool(note), policy_url=policy if policy_ok else ""),
    )
    await callback.answer()


@router.callback_query(F.data == "panel:button_labels")
async def panel_button_labels(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        repo = Repo(session)
        labels = {
            "policy": await repo.get_setting("btn_policy_label", "Политика обработки персональных данных"),
            "confirm": await repo.get_setting("btn_confirm_label", "Подтверждаю"),
            "materials": await repo.get_setting("btn_materials_label", "Скачать полезные материалы"),
            "consult": await repo.get_setting("btn_consult_label", "Записаться на консультацию"),
            "channel": await repo.get_setting("btn_channel_label", "📣 Подписаться на канал"),
        }
    await callback.message.answer(
        "<b>🔘 Основные кнопки воронки</b>\n\n"
        f"Политика: <b>{escape(labels['policy'])}</b>\n"
        f"Подтверждение: <b>{escape(labels['confirm'])}</b>\n"
        f"Материалы: <b>{escape(labels['materials'])}</b>\n"
        f"Консультация: <b>{escape(labels['consult'])}</b>\n"
        f"Подписка: <b>{escape(labels['channel'])}</b>",
        reply_markup=primary_button_labels_keyboard(),
    )
    await callback.answer()


@router.callback_query(
    (F.data == "panel:setting:btn_policy_label")
    | (F.data == "panel:setting:btn_confirm_label")
    | (F.data == "panel:setting:btn_materials_label")
    | (F.data == "panel:setting:btn_consult_label")
    | (F.data == "panel:setting:btn_channel_label")
)
async def primary_button_label_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                                     sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    key = callback.data.rsplit(":", 1)[1]
    defaults = {
        "btn_policy_label": "Политика обработки персональных данных",
        "btn_confirm_label": "Подтверждаю",
        "btn_materials_label": "Скачать полезные материалы",
        "btn_consult_label": "Записаться на консультацию",
        "btn_channel_label": "📣 Подписаться на канал",
    }
    async with sessions() as session:
        current = await Repo(session).get_setting(key, defaults[key])
    await state.update_data(setting_key=key, setting_kind="button_label")
    await state.set_state(SettingEdit.value)
    await callback.message.answer(
        f"Текущая подпись: <b>{escape(current)}</b>\n\nПришлите новую подпись кнопки (до 64 символов)."
    )
    await callback.answer()


@router.callback_query(F.data == "panel:problem_labels")
async def panel_problem_labels(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        repo = Repo(session)
        options = {
            key: await repo.get_setting(PROBLEM_SETTING_PREFIX + key, label)
            for key, label in texts.PROBLEM_OPTIONS.items()
        }
    await callback.message.answer(
        "<b>❓ Варианты ответа на вопрос через +2 дня</b>\n\n"
        "Нажмите вариант, чтобы изменить его подпись. Логика аналитики при этом не ломается.",
        reply_markup=problem_options_admin_keyboard(options),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("panel:problem_label:"))
async def problem_label_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                              sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    key = callback.data.rsplit(":", 1)[1]
    if key not in texts.PROBLEM_OPTIONS:
        await callback.answer("Неизвестный вариант", show_alert=True)
        return
    setting_key = PROBLEM_SETTING_PREFIX + key
    async with sessions() as session:
        current = await Repo(session).get_setting(setting_key, texts.PROBLEM_OPTIONS[key])
    await state.update_data(setting_key=setting_key, setting_kind="problem_label")
    await state.set_state(SettingEdit.value)
    await callback.message.answer(
        f"Сейчас: <b>{escape(current)}</b>\n\nПришлите новый текст кнопки (до 64 символов)."
    )
    await callback.answer()


@router.callback_query(
    (F.data == "panel:setting:privacy_policy_url")
    | (F.data == "panel:setting:materials_folder_url")
    | (F.data == "panel:setting:community_channel_url")
)
async def final_url_setting_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                                  sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    key = callback.data.rsplit(":", 1)[1]
    labels = {
        "privacy_policy_url": "ссылку на «Политику обработки персональных данных»",
        "materials_folder_url": "ссылку на папку с полезными материалами",
        "community_channel_url": "публичную ссылку на Telegram-канал для подписки (например https://t.me/hr_katerinaparipa)",
    }
    await state.update_data(setting_key=key, setting_kind="url")
    await state.set_state(SettingEdit.value)
    await callback.message.answer(f"Пришлите {labels[key]}. Чтобы убрать — <code>-</code>.")
    await callback.answer()


@router.callback_query(F.data == "panel:setting:subscription_nudge_minutes")
async def subscription_nudge_minutes_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                                           sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        current = await nudge_minutes(Repo(session), settings)
    await state.update_data(setting_key="subscription_nudge_minutes", setting_kind="minutes")
    await state.set_state(SettingEdit.value)
    await callback.message.answer(
        f"Сейчас мягкое напоминание о канале уходит через <b>{current} минут</b> после согласия.\n\n"
        "Пришлите число минут от 0 до 10080. <b>0</b> — выключить автоприглашение."
    )
    await callback.answer()


@router.callback_query(F.data == "panel:setting:work_chat_id")
async def work_chat_setting_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                                  sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await state.update_data(setting_key="work_chat_id", setting_kind="chat")
    await state.set_state(SettingEdit.value)
    await callback.message.answer(
        "Пришлите ID рабочего чата/канала (обычно выглядит как <code>-100...</code>) или @username канала.\n\n"
        "Для группы проще: добавьте бота в нужную группу и отправьте там команду /workchat_here."
    )
    await callback.answer()


@router.callback_query(F.data == "panel:setting:case_text")
async def case_text_setting_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                                  sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await state.update_data(setting_key="case_text", setting_kind="text")
    await state.set_state(SettingEdit.value)
    await callback.message.answer(
        "Пришлите финальный текст кейса, который должен уйти через 1 день после вопроса.\n"
        "Текст в ТЗ не указан, поэтому бот его не придумывает. Чтобы очистить — <code>-</code>."
    )
    await callback.answer()


@router.message(SettingEdit.value)
async def final_setting_edit_finish(message: Message, state: FSMContext, settings: Settings,
                                    sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    if not message.text:
        return
    data = await state.get_data()
    key = data.get("setting_key", "")
    kind = data.get("setting_kind", "")
    value = "" if message.text.strip() == "-" else message.text.strip()
    if kind == "url" and value and not _valid_url(value):
        await message.answer("Нужна корректная http/https-ссылка или <code>-</code>.")
        return
    if kind == "chat" and value:
        if not (value.startswith("@") or value.lstrip("-").isdigit()):
            await message.answer("Нужен числовой chat ID (например -100...) или @username.")
            return
    if kind == "minutes":
        if not value.isdigit() or not (0 <= int(value) <= 10080):
            await message.answer("Пришлите целое число минут от 0 до 10080.")
            return
    if kind in {"button_label", "problem_label"}:
        if not value:
            await message.answer("Подпись кнопки не может быть пустой.")
            return
        if len(value) > 64:
            await message.answer("Подпись слишком длинная. Максимум 64 символа.")
            return
    async with sessions() as session:
        await Repo(session).set_setting(key, value)
        await session.commit()
    await state.clear()
    await message.answer("✅ Настройка сохранена.", reply_markup=back_home_keyboard())


@router.callback_query(F.data == "panel:setting:welcome_video_note")
async def welcome_video_note_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                                   sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await state.clear()
    await state.set_state(WelcomeMediaEdit.asset)
    await callback.message.answer(
        "Перешлите сюда именно <b>Telegram-кружочек</b> (video note).\n\n"
        "Бот сохранит его Telegram file_id и будет отправлять этот кружок сразу после «Подтверждаю».\n"
        "/cancel — отмена"
    )
    await callback.answer()


@router.message(WelcomeMediaEdit.asset)
async def welcome_video_note_finish(message: Message, state: FSMContext, settings: Settings,
                                    sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    if not message.video_note:
        await message.answer(
            "Это не Telegram-кружочек. Перешлите сообщение, которое в Telegram отображается круглым видео."
        )
        return
    async with sessions() as session:
        repo = Repo(session)
        await repo.set_setting("welcome_video_note_file_id", message.video_note.file_id)
        # Keep compatibility with the previous release too.
        await repo.set_setting("welcome_media_kind", "video_note")
        await repo.set_setting("welcome_media_file_id", message.video_note.file_id)
        await session.commit()
    await state.clear()
    await message.answer("✅ Кружочек сохранён. Он будет первым приветственным сообщением после согласия.", reply_markup=back_home_keyboard())


@router.callback_query(F.data == "panel:preview_welcome")
async def preview_welcome(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        repo = Repo(session)
        note = await repo.get_setting("welcome_video_note_file_id", "")
        welcome = await repo.get_text("welcome", texts.WELCOME)
        materials_label = await repo.get_setting("btn_materials_label", "Скачать полезные материалы")
        consult_label = await repo.get_setting("btn_consult_label", "Записаться на консультацию")
        channel_label = await repo.get_setting("btn_channel_label", "📣 Подписаться на канал")
        _channel, channel_url = await resolve_promo_channel(repo, settings)
        extra_buttons = await repo.buttons(screen="welcome", active_only=True)
    if note:
        try:
            await callback.message.answer_video_note(note)
        except Exception as exc:
            await callback.message.answer(f"⚠️ Не удалось отправить кружок: <code>{escape(str(exc))}</code>")
    else:
        await callback.message.answer("⚠️ Кружочек ещё не загружен.")
    material_url = make_materials_tracking_url(settings, callback.from_user.id)
    from app.bot.keyboards import main_menu_keyboard
    await callback.message.answer(
        welcome,
        reply_markup=main_menu_keyboard(
            material_url,
            materials_label=materials_label,
            consult_label=consult_label,
            buttons=extra_buttons,
            channel_url=channel_url,
            channel_label=channel_label,
        ),
    )
    await callback.answer("Предпросмотр отправлен")


@router.callback_query(F.data == "panel:preview_consent")
async def preview_consent(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        repo = Repo(session)
        policy = await repo.get_setting("privacy_policy_url", settings.privacy_policy_url or settings.legal_docs_url)
        if policy and not _valid_url(policy):
            policy = ""
        intro = await repo.get_text("consent_intro", TEXT_DEFAULTS["consent_intro"])
        policy_label = await repo.get_setting("btn_policy_label", "Политика обработки персональных данных")
        confirm_label = await repo.get_setting("btn_confirm_label", "Подтверждаю")
        channel_label = await repo.get_setting("btn_channel_label", "📣 Подписаться на канал")
        _channel, channel_url = await resolve_promo_channel(repo, settings)
    from app.bot.keyboards import consent_keyboard
    if policy:
        body = f"{intro}\n\n<a href=\"{escape(policy, quote=True)}\">{escape(policy_label)}</a>"
    else:
        body = intro + "\n\n⚠️ Ссылка на Политику ПД ещё не настроена. Подтверждение пользователю будет недоступно."
    await callback.message.answer(
        body,
        reply_markup=consent_keyboard(
            policy,
            policy_label=policy_label,
            confirm_label=confirm_label,
            allow_confirm=bool(policy),
            confirm_callback="panel:preview_welcome",
            channel_url=channel_url,
            channel_label=channel_label,
        ),
    )
    await callback.answer("Предпросмотр отправлен")


@router.callback_query(F.data == "panel:automation_preview")
async def final_automation_preview(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        repo = Repo(session)
        case_text = await repo.get_setting("case_text", texts.CASE_DEFAULT)
        offer_4h = await repo.get_text("consult_offer_4h", texts.CONSULT_OFFER_4H)
        problem_question = await repo.get_text("problem_question", texts.PROBLEM_QUESTION)
        problem_options = {
            key: await repo.get_setting(PROBLEM_SETTING_PREFIX + key, label)
            for key, label in texts.PROBLEM_OPTIONS.items()
        }
        consult_label = await repo.get_setting("btn_consult_label", "Записаться на консультацию")
        subscription_copy = await repo.get_text("subscription_nudge", TEXT_DEFAULTS["subscription_nudge"])
        subscribe_label = await repo.get_setting("btn_channel_label", "📣 Подписаться на канал")
        _channel, channel_url = await resolve_promo_channel(repo, settings)
        sub_minutes = await nudge_minutes(repo, settings)
    await callback.message.answer("<b>🧪 Предпросмотр итоговой воронки. Таймеры не создаются.</b>")
    if channel_url and sub_minutes > 0:
        from app.bot.keyboards import subscription_keyboard
        await callback.message.answer(
            f"<b>+{sub_minutes} мин после согласия · только если человек не подписан</b>\n\n" + subscription_copy,
            reply_markup=subscription_keyboard(channel_url, subscribe_label=subscribe_label),
        )
    from app.bot.keyboards import consult_keyboard, pain_keyboard
    await callback.message.answer(
        "<b>+4 часа от клика материалов</b>\n\n" + offer_4h,
        reply_markup=consult_keyboard(label=consult_label),
    )
    await callback.message.answer(
        "<b>+2 дня от входа</b>\n\n" + problem_question,
        reply_markup=pain_keyboard(problem_options),
    )
    await callback.message.answer(
        "<b>+1 день после вопроса</b>\n\n" + (case_text if case_text.strip() else "⚠️ Текст кейса ещё не задан в настройках."),
        reply_markup=consult_keyboard(label=consult_label),
    )
    await callback.message.answer("<b>+24 часа от материалов</b>\n\nПользователю ничего не отправляется. Уведомление получает только рабочий чат.")
    await callback.answer("Предпросмотр отправлен")


@router.callback_query(F.data == "panel:test_work_chat")
async def test_work_chat(callback: CallbackQuery, bot: Bot, settings: Settings,
                         sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    ok = await notify_work_chat(
        bot, settings, sessions,
        "✅ <b>Тест рабочего чата</b>\nСлужебные уведомления бота будут приходить сюда."
    )
    await callback.answer("Тест отправлен" if ok else "Рабочий чат не настроен / недоступен", show_alert=not ok)


@router.message(Command("workchat_here"))
async def workchat_here(message: Message, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    if message.chat.type == "private":
        await message.answer("Эту команду нужно отправить внутри рабочего группового чата.")
        return
    async with sessions() as session:
        await Repo(session).set_setting("work_chat_id", str(message.chat.id))
        await session.commit()
    await message.answer(f"✅ Этот чат сохранён как рабочий. ID: <code>{message.chat.id}</code>")


# ------------------------ Campaigns -----------------------------------
@router.callback_query(F.data == "panel:campaigns")
async def panel_campaigns(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    async with sessions() as session:
        items = await Repo(session).campaigns(15)
    lines = ["<b>🎯 Рекламные источники</b>"]
    for item in items:
        lines.append(f"\n<code>{escape(item.code)}</code> · {escape(item.channel or 'без названия')}")
    if not items:
        lines.append("\n\nПока нет источников.")
    await callback.message.answer("".join(lines), reply_markup=campaigns_admin_keyboard(items))
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:campaign:\d+$"))
async def campaign_details(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    campaign_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        repo = Repo(session)
        item = await repo.get_campaign_by_id(campaign_id)
        if not item:
            await callback.answer("Источник не найден", show_alert=True)
            return
        material = await repo.campaign_material(item.code)
    await callback.message.answer(
        f"<b>🎯 Источник</b>\n\nКанал: <b>{escape(item.channel or 'без названия')}</b>\n"
        f"Код: <code>{escape(item.code)}</code>\nUTM source: <code>{escape(item.utm_source or '—')}</code>\n"
        f"UTM campaign: <code>{escape(item.utm_campaign or '—')}</code>\nUTM content: <code>{escape(item.utm_content or '—')}</code>\n"
        f"Первым покажется: <b>{escape(material.title if material else 'общий первый материал')}</b>",
        reply_markup=campaign_admin_keyboard(item.id),
    )
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:campaign_material_pick:\d+$"))
async def campaign_material_pick(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    campaign_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        repo = Repo(session)
        item = await repo.get_campaign_by_id(campaign_id)
        materials = await repo.materials(active_only=True)
    if not item:
        await callback.answer("Источник не найден", show_alert=True)
        return
    await callback.message.answer(f"Какой материал показать первым для <code>{escape(item.code)}</code>?", reply_markup=campaign_material_keyboard(item.id, materials))
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:campaign_delete_ask:\d+$"))
async def campaign_delete_ask(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    campaign_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        item = await Repo(session).get_campaign_by_id(campaign_id)
    if not item:
        await callback.answer("Источник уже удалён", show_alert=True)
        return
    await callback.message.answer(
        f"Удалить источник <b>{escape(item.channel or item.code)}</b>? Исторические лиды/события останутся.",
        reply_markup=campaign_delete_keyboard(item.id),
    )
    await callback.answer()


@router.callback_query(F.data.regexp(r"^panel:campaign_delete:\d+$"))
async def campaign_delete(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    campaign_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        repo = Repo(session)
        item = await repo.delete_campaign(campaign_id)
        await session.commit()
        items = await repo.campaigns(15)
    if not item:
        await callback.answer("Источник уже удалён", show_alert=True)
        return
    await callback.message.answer(f"✅ Источник <code>{escape(item.code)}</code> удалён.", reply_markup=campaigns_admin_keyboard(items))
    await callback.answer("Удалено")


@router.callback_query(F.data == "panel:campaign_add")
async def campaign_add_start(callback: CallbackQuery, state: FSMContext, settings: Settings,
                             sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await state.clear()
    await state.set_state(CampaignAdd.code)
    await callback.message.answer("<b>Новый источник · 1/5</b>\nКод, например <code>hr_channel_01</code>.")
    await callback.answer()


@router.message(CampaignAdd.code)
async def campaign_add_code(message: Message, state: FSMContext) -> None:
    if not message.text:
        return
    code = message.text.strip()
    try:
        validate_campaign_code(code)
    except ValueError as exc:
        await message.answer(escape(str(exc)))
        return
    await state.update_data(code=code)
    await state.set_state(CampaignAdd.channel)
    await message.answer("<b>2/5</b> Название канала/площадки.")


@router.message(CampaignAdd.channel)
async def campaign_add_channel(message: Message, state: FSMContext) -> None:
    if not message.text:
        return
    await state.update_data(channel=message.text.strip()[:256])
    await state.set_state(CampaignAdd.source)
    await message.answer("<b>3/5</b> UTM source, например <code>telegram</code>.")


@router.message(CampaignAdd.source)
async def campaign_add_source(message: Message, state: FSMContext) -> None:
    if not message.text:
        return
    await state.update_data(source=message.text.strip()[:128])
    await state.set_state(CampaignAdd.campaign)
    await message.answer("<b>4/5</b> Название кампании, например <code>hr_september</code>.")


@router.message(CampaignAdd.campaign)
async def campaign_add_campaign(message: Message, state: FSMContext) -> None:
    if not message.text:
        return
    await state.update_data(campaign=message.text.strip()[:128])
    await state.set_state(CampaignAdd.content)
    await message.answer("<b>5/5</b> Креатив/пост, например <code>post_1</code>.")


@router.message(CampaignAdd.content)
async def campaign_add_finish(message: Message, state: FSMContext, bot: Bot, settings: Settings,
                              sessions: async_sessionmaker) -> None:
    if not await _allowed(message.from_user.id, settings, sessions) or not message.text:
        return
    data = await state.get_data()
    async with sessions() as session:
        repo = Repo(session)
        item = await repo.save_campaign(
            code=data["code"], utm_source=data["source"], utm_medium="bot", utm_campaign=data["campaign"],
            utm_content=message.text.strip()[:128], channel=data["channel"],
        )
        materials = await repo.materials(active_only=True)
        await session.commit()
    await state.clear()
    await message.answer(
        f"✅ <b>Источник создан:</b> <code>{escape(item.code)}</code>\n\n"
        "Можно выбрать, какой материал будет первым. Остальные активные материалы тоже будут видны.",
        reply_markup=campaign_material_keyboard(item.id, materials),
    )


@router.callback_query(F.data.regexp(r"^panel:campaign_material:\d+:\d+$"))
async def campaign_material_bind(callback: CallbackQuery, bot: Bot, settings: Settings,
                                 sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    _, _, raw_campaign_id, raw_material_id = callback.data.split(":", 3)
    campaign_id, material_id = int(raw_campaign_id), int(raw_material_id)
    async with sessions() as session:
        repo = Repo(session)
        campaign = await repo.get_campaign_by_id(campaign_id)
        if not campaign:
            await callback.answer("Источник не найден", show_alert=True)
            return
        material = await repo.get_material(material_id) if material_id else None
        if material_id and (not material or not material.is_active):
            await callback.answer("Материал недоступен", show_alert=True)
            return
        await repo.set_campaign_material(campaign.code, material_id or None)
        await session.commit()
    me = await bot.get_me()
    direct = f"https://t.me/{me.username}?start={campaign.code}"
    tracked = f"{settings.public_base_url.rstrip('/')}/go/{campaign.code}" if settings.public_base_url else ""
    await callback.message.answer(
        f"✅ <b>Источник готов</b>\n\nКанал: {escape(campaign.channel or '')}\nКод: <code>{escape(campaign.code)}</code>\n"
        f"Первый материал: <b>{escape(material.title if material else 'общий')}</b>\n\n"
        f"Ссылка для рекламы:\n<code>{escape(tracked or direct)}</code>",
        reply_markup=back_home_keyboard(),
    )
    await callback.answer("Готово")


# ------------------------ Leads & stats -------------------------------
@router.message(Command("stats"))
async def stats(message: Message, settings: Settings, sessions: async_sessionmaker) -> None:
    if await _allowed(message.from_user.id, settings, sessions):
        await message.answer(await _stats_text(sessions))


@router.callback_query(F.data == "panel:stats")
async def panel_stats(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await callback.message.answer(await _stats_text(sessions), reply_markup=back_home_keyboard())
    await callback.answer()


async def _leads_text(sessions: async_sessionmaker) -> str:
    async with sessions() as session:
        repo = Repo(session)
        items = await repo.recent_leads(15)
        rows = []
        for lead in items:
            consent = await repo.get_consent(lead.telegram_id)
            rows.append((lead, Repo.privacy_allowed(consent), Repo.marketing_allowed(consent)))
    if not rows:
        return "Лидов пока нет."
    lines = ["<b>👥 Последние лиды</b>"]
    for lead, privacy, marketing in rows:
        username = f"@{escape(lead.username)}" if lead.username else str(lead.telegram_id)
        consent_icon = "✅" if privacy else "⏳"
        mail_icon = "🔔" if marketing else "🔕"
        lines.append(f"\n#{lead.id} {username} · <b>{escape(lead.stage)}</b> · {consent_icon}{mail_icon} · <code>{escape(lead.source_code)}</code>")
    return "".join(lines)


@router.message(Command("leads"))
async def leads(message: Message, settings: Settings, sessions: async_sessionmaker) -> None:
    if await _allowed(message.from_user.id, settings, sessions):
        await message.answer(await _leads_text(sessions))


@router.callback_query(F.data == "panel:leads")
async def panel_leads(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        return
    await callback.message.answer(await _leads_text(sessions), reply_markup=back_home_keyboard())
    await callback.answer()


# ------------------------ Manager messaging ---------------------------
@router.callback_query(F.data.regexp(r"^admin:script_(pain|consult):\d+$"))
async def admin_quick_script(callback: CallbackQuery, bot: Bot, settings: Settings,
                             sessions: async_sessionmaker, sheets: SheetsMirror) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        await callback.answer("Недоступно", show_alert=True)
        return
    parts = callback.data.split(":")
    script_name = parts[1].replace("script_", "")
    telegram_id = int(parts[2])
    key = "manager_pain_script" if script_name == "pain" else "manager_consult_script"
    default = texts.MANAGER_PAIN_SCRIPT if script_name == "pain" else texts.MANAGER_CONSULT_SCRIPT
    async with sessions() as session:
        repo = Repo(session)
        lead = await repo.get_lead(telegram_id)
        if not lead:
            await callback.answer("Лид не найден", show_alert=True)
            return
        consent = await repo.get_consent(telegram_id)
        if not Repo.marketing_allowed(consent) and lead.stage not in {"consultation_requested", "consultation"}:
            await callback.answer("Лид ещё не подтвердил согласие на рассылку", show_alert=True)
            return
        copy = await repo.get_text(key, default)
        analytics = Analytics(repo, sheets)
        try:
            await bot.send_message(telegram_id, render_text(copy, first_name=lead.first_name))
        except Exception as exc:
            await callback.answer("Не удалось доставить", show_alert=True)
            await callback.message.answer(f"Ошибка: <code>{escape(str(exc)[:500])}</code>")
            return
        await repo.advance_stage(lead, "contacted")
        if script_name == "consult":
            await repo.cancel_touches(lead, ["consult_nudge_4h", "manager_followup_24h"])
        await analytics.event(f"manager_script_{script_name}", lead=lead, payload={"manager_id": callback.from_user.id})
        await analytics.lead_snapshot(lead)
        await session.commit()
    await callback.answer("✅ Отправлено")
    await callback.message.answer("✅ Готовое сообщение доставлено лиду.")


@router.callback_query(F.data.startswith("admin:write:"))
async def admin_write(callback: CallbackQuery, state: FSMContext, settings: Settings,
                      sessions: async_sessionmaker) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        await callback.answer("Недоступно", show_alert=True)
        return
    telegram_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        repo = Repo(session)
        lead = await repo.get_lead(telegram_id)
        consent = await repo.get_consent(telegram_id)
    if not lead:
        await callback.answer("Лид не найден", show_alert=True)
        return
    if not Repo.marketing_allowed(consent) and lead.stage not in {"consultation_requested", "consultation"}:
        await callback.answer("Лид ещё не подтвердил согласие на рассылку", show_alert=True)
        return
    await callback.answer("Режим сообщения открыт")
    await state.set_state(AdminWrite.waiting_text)
    await state.update_data(lead_telegram_id=telegram_id)
    target = f"@{escape(lead.username)}" if lead.username else f"ID {telegram_id}"
    await callback.message.answer(f"✍️ <b>Сообщение лиду {target}</b>\n\nОтправьте текст следующим сообщением. /cancel — отмена")


@router.message(AdminWrite.waiting_text)
async def send_to_lead(message: Message, state: FSMContext, bot: Bot, settings: Settings,
                       sessions: async_sessionmaker, sheets: SheetsMirror) -> None:
    if not await _allowed(message.from_user.id, settings, sessions):
        return
    data = await state.get_data()
    telegram_id = int(data["lead_telegram_id"])
    if not message.text:
        await message.answer("Пока поддерживается текстовое сообщение.")
        return
    try:
        await bot.send_message(telegram_id, f"<b>Сообщение команды</b>\n\n{escape(message.text)}")
    except Exception as exc:
        await message.answer(f"Не удалось доставить: {escape(str(exc))}")
        await state.clear()
        return
    async with sessions() as session:
        repo = Repo(session)
        analytics = Analytics(repo, sheets)
        lead = await repo.get_lead(telegram_id)
        if lead:
            await repo.advance_stage(lead, "contacted")
            await analytics.event("manager_message", lead=lead, payload={"manager_id": message.from_user.id})
            await analytics.lead_snapshot(lead)
            await session.commit()
    await state.clear()
    await message.answer("✅ Сообщение доставлено.")


@router.callback_query(F.data.regexp(r"^admin:subcheck:\d+$"))
async def admin_subscription_check(callback: CallbackQuery, bot: Bot, settings: Settings,
                                   sessions: async_sessionmaker, sheets: SheetsMirror) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        await callback.answer("Недоступно", show_alert=True)
        return
    telegram_id = int(callback.data.rsplit(":", 1)[1])
    async with sessions() as session:
        repo = Repo(session)
        lead = await repo.get_lead(telegram_id)
        channel, channel_url = await resolve_promo_channel(repo, settings)
    if not lead:
        await callback.answer("Лид не найден", show_alert=True)
        return
    if not channel:
        await callback.answer("Канал для подписки не настроен", show_alert=True)
        return
    check = await check_channel_subscription(bot, telegram_id, channel)
    if check.subscribed:
        async with sessions() as session:
            repo = Repo(session)
            analytics = Analytics(repo, sheets)
            lead = await repo.get_lead(telegram_id)
            if lead and not await repo.has_event(lead, "subscription_verified"):
                await analytics.event("subscription_verified", lead=lead, payload={"channel": channel, "checked_by_admin": callback.from_user.id})
                await analytics.lead_snapshot(lead)
                await session.commit()
        await callback.answer("✅ Подписан", show_alert=True)
    elif check.status in {"left", "kicked", "banned", "restricted"}:
        await callback.answer("❌ Не подписан", show_alert=True)
    else:
        await callback.answer("⚠️ Не удалось проверить: проверьте, что бот администратор канала", show_alert=True)


@router.callback_query(F.data.regexp(r"^admin:(contact|consulted|deal|lost):\d+$"))
async def admin_stage(callback: CallbackQuery, settings: Settings, sessions: async_sessionmaker,
                      sheets: SheetsMirror) -> None:
    if not await _allowed(callback.from_user.id, settings, sessions):
        await callback.answer("Недоступно", show_alert=True)
        return
    _, action, raw_id = callback.data.split(":", 2)
    telegram_id = int(raw_id)
    mapping = {
        "contact": ("contacted", "📞 В работе"),
        "consulted": ("consultation", "✅ Консультация была"),
        "deal": ("deal", "💰 Сделка"),
        "lost": ("lost", "✖️ Отказ"),
    }
    stage, stage_label = mapping[action]
    await callback.answer(stage_label)
    try:
        async with sessions() as session:
            repo = Repo(session)
            analytics = Analytics(repo, sheets)
            lead = await repo.get_lead(telegram_id)
            if not lead:
                await callback.message.answer(f"⚠️ Лид ID <code>{telegram_id}</code> не найден.")
                return
            await repo.advance_stage(lead, stage)
            if action in {"consulted", "deal", "lost"}:
                await repo.cancel_touches(lead)
            await analytics.event(f"manager_{action}", lead=lead, payload={"manager_id": callback.from_user.id})
            await analytics.lead_snapshot(lead)
            await session.commit()
            username = f"@{escape(lead.username)}" if lead.username else f"ID {telegram_id}"
        await callback.message.answer(f"✅ <b>Статус лида обновлён</b>\nЛид: {username}\nСтатус: <b>{stage_label}</b>")
    except Exception as exc:
        print(f"[admin callback] action={action} lead={telegram_id}: {exc}")
        await callback.message.answer("⚠️ Не удалось изменить статус. Ошибка записана в лог.")
