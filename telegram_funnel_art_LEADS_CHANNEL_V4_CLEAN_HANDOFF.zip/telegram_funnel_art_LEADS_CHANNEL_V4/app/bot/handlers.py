# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from html import escape
from urllib.parse import urlparse

from aiogram import Bot, F, Router
from aiogram.filters import CommandStart
from aiogram.filters.command import CommandObject
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.bot import texts
from app.bot.keyboards import (
    admin_home_keyboard,
    consent_keyboard,
    folder_open_keyboard,
    main_menu_keyboard,
    pain_keyboard,
    subscription_keyboard,
)
from app.config import Settings
from app.db.repo import Repo
from app.services.access import is_admin
from app.services.channel_promo import nudge_minutes, resolve_promo_channel
from app.services.analytics import Analytics
from app.services.funnel_actions import campaign_label, record_consultation_request, record_material_click
from app.services.material_link import make_materials_tracking_url
from app.services.lead_alerts import notify_new_lead_admins
from app.services.sheets import SheetsMirror
from app.services.timefmt import as_utc, fmt_moscow
from app.services.tracking import normalize_source
from app.services.subscription import check_channel_subscription
from app.services.workchat import notify_work_chat

router = Router(name="funnel_final_tz")

CONSENT_VERSION = "2026-09-05-final-tz"


def _scaled_hours(settings: Settings, hours: float) -> timedelta:
    return timedelta(hours=hours * max(settings.automation_time_scale, 0.0001))


def _full_name(first_name: str | None, last_name: str | None) -> str:
    return " ".join(x for x in [first_name, last_name] if x).strip() or "—"


async def _policy_url(repo: Repo, settings: Settings) -> str:
    value = (await repo.get_setting(
        "privacy_policy_url", settings.privacy_policy_url or settings.legal_docs_url
    )).strip()
    if not value:
        return ""
    try:
        parsed = urlparse(value)
        if parsed.scheme in {"http", "https"} and parsed.netloc:
            return value
    except Exception:
        pass
    return ""


async def _welcome_video_note(repo: Repo) -> str:
    value = await repo.get_setting("welcome_video_note_file_id", "")
    if value:
        return value
    # Upgrade compatibility: V2 stored kind + file_id separately.
    kind = await repo.get_setting("welcome_media_kind", "")
    if kind == "video_note":
        return await repo.get_setting("welcome_media_file_id", "")
    return ""


async def _send_welcome(message: Message, settings: Settings, sessions: async_sessionmaker) -> None:
    async with sessions() as session:
        repo = Repo(session)
        video_note_id = await _welcome_video_note(repo)
        welcome = await repo.get_text("welcome", texts.WELCOME)
        materials_label = await repo.get_setting("btn_materials_label", "Скачать полезные материалы")
        consult_label = await repo.get_setting("btn_consult_label", "Записаться на консультацию")
        channel_label = await repo.get_setting("btn_channel_label", "📣 Подписаться на канал")
        _channel, channel_url = await resolve_promo_channel(repo, settings)
        extra_buttons = await repo.buttons(screen="welcome", active_only=True)
    if video_note_id:
        try:
            await message.answer_video_note(video_note_id)
        except Exception as exc:
            print(f"[welcome video_note] {type(exc).__name__}: {exc}")

    materials_url = make_materials_tracking_url(settings, message.from_user.id)
    await message.answer(
        welcome,
        reply_markup=main_menu_keyboard(
            materials_url,
            materials_label=materials_label,
            consult_label=consult_label,
            buttons=extra_buttons,
            channel_url=channel_url,
            channel_label=channel_label,
        ),
    )


@router.message(CommandStart())
async def start(
    message: Message,
    command: CommandObject,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> None:
    if await is_admin(message.from_user.id, settings, sessions):
        await message.answer(
            "<b>Панель управления — Вселенная кадров</b>\n\n"
            "Можно менять тексты, кнопки, ссылки, кружочек и проверять воронку глазами клиента.",
            reply_markup=admin_home_keyboard(),
        )
        return

    source = normalize_source(command.args)
    async with sessions() as session:
        repo = Repo(session)
        analytics = Analytics(repo, sheets)
        lead, created = await repo.upsert_lead(
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            last_name=message.from_user.last_name,
            source_code=source,
        )
        consent = await repo.get_consent(lead.telegram_id)
        policy_url = await _policy_url(repo, settings)
        consent_intro = await repo.get_text(
            "consent_intro",
            "Перед продолжением ознакомьтесь с Политикой обработки персональных данных и подтвердите согласие.",
        )
        policy_label = await repo.get_setting("btn_policy_label", "Политика обработки персональных данных")
        confirm_label = await repo.get_setting("btn_confirm_label", "Подтверждаю")
        channel_label = await repo.get_setting("btn_channel_label", "📣 Подписаться на канал")
        _channel, channel_url = await resolve_promo_channel(repo, settings)
        source_label = await campaign_label(repo, lead.source_code)
        await analytics.event(
            "start" if created else "restart",
            lead=lead,
            payload={"deep_link": source, "new_lead": created},
        )
        await analytics.lead_snapshot(lead)
        await session.commit()

    # V4: restore the old useful behavior — a brand-new entry is immediately sent
    # to every configured admin in a private bot chat. Work-chat notifications for
    # later funnel events remain separate.
    if created:
        await notify_new_lead_admins(bot, settings, sessions, lead, source_label=source_label)

    # Consent is still the only gate for the main funnel. Channel subscription is soft/non-blocking.
    if Repo.privacy_allowed(consent):
        await _send_welcome(message, settings, sessions)
    else:
        if policy_url:
            body = (
                f"{consent_intro}\n\n"
                f"<a href=\"{escape(policy_url, quote=True)}\">{escape(policy_label)}</a>"
            )
        else:
            body = (
                f"{consent_intro}\n\n"
                "⚠️ Политика обработки персональных данных временно недоступна. "
                "Продолжить пока нельзя."
            )
        await message.answer(
            body,
            reply_markup=consent_keyboard(
                policy_url,
                policy_label=policy_label,
                confirm_label=confirm_label,
                allow_confirm=bool(policy_url),
                channel_url=channel_url,
                channel_label=channel_label,
            ),
        )


@router.callback_query(F.data == "consent:confirm")
async def consent_confirm(
    callback: CallbackQuery,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> None:
    async with sessions() as session:
        repo = Repo(session)
        analytics = Analytics(repo, sheets)
        lead = await repo.get_lead(callback.from_user.id)
        if not lead:
            await callback.answer("Сначала нажмите /start", show_alert=True)
            return
        policy_url = await _policy_url(repo, settings)
        if not policy_url:
            await callback.answer(
                "Политика ПД ещё не настроена администратором. Подтверждение недоступно.",
                show_alert=True,
            )
            return

        already = await repo.has_event(lead, "consent_confirmed")
        consent = await repo.accept_privacy(lead, version=CONSENT_VERSION)
        if not already:
            event = await analytics.event(
                "consent_confirmed",
                lead=lead,
                payload={"version": CONSENT_VERSION},
            )
            # Compatibility with the already-connected analytics sheet.
            await analytics.event("consent_accepted", lead=lead, payload={"privacy": True, "final_tz": True})
            # Timer point is the original bot entry, but the chain starts only after consent.
            due = as_utc(lead.created_at) + _scaled_hours(settings, 48)
            await repo.schedule_touch(lead, "problem_question_48h", due)
            # Soft channel nudge: independent of the funnel and never blocks materials/consultation.
            minutes = await nudge_minutes(repo, settings)
            if minutes > 0:
                await repo.schedule_touch(
                    lead,
                    "channel_subscription_nudge",
                    event.created_at + timedelta(minutes=minutes * max(settings.automation_time_scale, 0.0001)),
                )
            await analytics.lead_snapshot(lead)
            consent_at = event.created_at
        else:
            consent_at = consent.privacy_accepted_at

        source = await campaign_label(repo, lead.source_code)
        name = _full_name(lead.first_name, lead.last_name)
        username = f"@{lead.username}" if lead.username else "—"
        await session.commit()

    if not already:
        await notify_work_chat(
            bot,
            settings,
            sessions,
            "✅ <b>Пользователь подтвердил согласие на обработку ПД</b>\n"
            f"Имя: <b>{escape(name)}</b>\n"
            f"Username: {escape(username)}\n"
            f"Telegram ID: <code>{callback.from_user.id}</code>\n"
            f"Дата и время: <b>{fmt_moscow(consent_at)}</b>\n"
            f"Источник: <b>{escape(source)}</b>",
        )

    await callback.answer("Подтверждено")
    await _send_welcome(callback.message, settings, sessions)


@router.callback_query(F.data == "subscription_check")
async def subscription_check(
    callback: CallbackQuery,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> None:
    async with sessions() as session:
        repo = Repo(session)
        analytics = Analytics(repo, sheets)
        lead = await repo.get_lead(callback.from_user.id)
        channel, channel_url = await resolve_promo_channel(repo, settings)
        if not lead:
            await callback.answer("Сначала нажмите /start", show_alert=True)
            return
        if not channel:
            await callback.answer("Канал ещё не настроен администратором", show_alert=True)
            return

    check = await check_channel_subscription(bot, callback.from_user.id, channel)
    if check.subscribed:
        async with sessions() as session:
            repo = Repo(session)
            analytics = Analytics(repo, sheets)
            lead = await repo.get_lead(callback.from_user.id)
            if lead and not await repo.has_event(lead, "subscription_verified"):
                await analytics.event("subscription_verified", lead=lead, payload={"channel": channel, "soft_gate": True})
                await analytics.lead_snapshot(lead)
                await session.commit()
        await callback.answer("✅ Подписка подтверждена. Спасибо!", show_alert=True)
        return

    if check.status in {"bot_not_admin", "api_error", "channel_error"}:
        await callback.answer("⚠️ Сейчас не удалось проверить подписку. Попробуйте чуть позже.", show_alert=True)
    else:
        await callback.answer("Пока не вижу подписку. Подпишитесь на канал и нажмите проверку ещё раз.", show_alert=True)


@router.callback_query(F.data == "materials")
async def materials_fallback(
    callback: CallbackQuery,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> None:
    """Fallback only when PUBLIC_BASE_URL is absent.

    With PUBLIC_BASE_URL the main button is a signed URL and the same click both records
    analytics and redirects straight to Google Drive, exactly as specified in the TZ.
    """
    first, folder_url = await record_material_click(
        telegram_id=callback.from_user.id,
        bot=bot,
        settings=settings,
        sessions=sessions,
        sheets=sheets,
    )
    if not folder_url:
        await callback.answer("Папка с материалами ещё не настроена", show_alert=True)
        return
    await callback.message.answer(
        "Откройте папку с полезными материалами:",
        reply_markup=folder_open_keyboard(folder_url),
    )
    await callback.answer("Материалы открыты" if first else "Открываю материалы")


@router.callback_query(F.data == "consult")
async def consult(
    callback: CallbackQuery,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> None:
    ok = await record_consultation_request(
        telegram_id=callback.from_user.id,
        bot=bot,
        settings=settings,
        sessions=sessions,
        sheets=sheets,
    )
    if not ok:
        await callback.answer("Сначала нажмите /start и подтвердите согласие", show_alert=True)
        return
    async with sessions() as session:
        consult_requested_text = await Repo(session).get_text("consult_requested", texts.CONSULT_REQUESTED)
    await callback.message.answer(consult_requested_text)
    await callback.answer("Заявка передана")


@router.callback_query(F.data.startswith("problem:"))
async def problem_answer(
    callback: CallbackQuery,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> None:
    key = callback.data.split(":", 1)[1]
    default_label = texts.PROBLEM_OPTIONS.get(key)
    if not default_label:
        await callback.answer("Неизвестный вариант", show_alert=True)
        return

    async with sessions() as session:
        repo = Repo(session)
        label = await repo.get_setting("problem_label_" + key, default_label)
        analytics = Analytics(repo, sheets)
        lead = await repo.get_lead(callback.from_user.id)
        if not lead:
            await callback.answer("Сначала нажмите /start", show_alert=True)
            return
        if await repo.has_event(lead, "problem_answered"):
            await callback.answer("Ответ уже сохранён")
            return

        await repo.set_pain(lead, label)
        event = await analytics.event("problem_answered", lead=lead, payload={"key": key, "answer": label})
        # Compatibility event for the existing sheet funnel.
        await analytics.event("qualified", lead=lead, payload={"pain": key, "final_tz": True})
        await analytics.lead_snapshot(lead)
        source = await campaign_label(repo, lead.source_code)
        name = _full_name(lead.first_name, lead.last_name)
        username = f"@{lead.username}" if lead.username else "—"
        await session.commit()

    await notify_work_chat(
        bot,
        settings,
        sessions,
        "🧭 <b>Пользователь ответил на вопрос о текущей проблеме</b>\n"
        f"Имя: <b>{escape(name)}</b>\n"
        f"Username: {escape(username)}\n"
        f"Telegram ID: <code>{callback.from_user.id}</code>\n"
        f"Ответ: <b>{escape(label)}</b>\n"
        f"Дата и время: <b>{fmt_moscow(event.created_at)}</b>\n"
        f"Источник: <b>{escape(source)}</b>",
    )
    # Final TZ: after the selection send no additional question/message to the user.
    await callback.answer("Ответ сохранён")
