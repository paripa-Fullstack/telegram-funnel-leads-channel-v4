# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import asyncio

import uvicorn
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from fastapi import FastAPI

from app.bot import admin, handlers
from app.config import get_settings
from app.db.session import Database
from app.services.automation import automation_loop
from app.services.migration import migrate_final_tz
from app.services.sheets import SheetsMirror
from app.services.workchat import resolve_work_chat
from app.web.routes import router as web_router


async def main() -> None:
    settings = get_settings()
    database = Database(settings.database_url)
    await database.init()

    bot = Bot(settings.telegram_bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    me = await bot.get_me()

    sheets = SheetsMirror(settings)
    await migrate_final_tz(settings, database.session_factory)

    dp = Dispatcher()
    dp["settings"] = settings
    dp["sessions"] = database.session_factory
    dp["sheets"] = sheets
    dp.include_router(admin.router)
    dp.include_router(handlers.router)

    app = FastAPI(title="Вселенная кадров — Leads + Channel V4", docs_url=None, redoc_url=None)
    app.state.sessions = database.session_factory
    app.state.sheets = sheets
    app.state.settings = settings
    app.state.bot = bot
    app.state.bot_username = me.username
    app.include_router(web_router)

    config = uvicorn.Config(app, host=settings.app_host, port=settings.app_port, log_level="info")
    server = uvicorn.Server(config)

    print(f"Bot: @{me.username}")
    print("Release: LEADS_CHANNEL_V4")
    if settings.public_base_url:
        print(f"Tracked materials redirect: READY ({settings.public_base_url.rstrip('/')}/materials/...)")
    else:
        print("Tracked materials redirect: FALLBACK (PUBLIC_BASE_URL is empty; materials need a second tap)")
    sheets_ok, sheets_info = await sheets.diagnose()
    print(f"Google Sheets: {'READY' if sheets_ok else 'WAITING'} ({sheets_info})")
    work_chat = await resolve_work_chat(settings, database.session_factory)
    print(f"Work chat: {'READY ' + work_chat if work_chat else 'NOT CONFIGURED'}")
    print("Automation engine: READY (+4h / +24h from materials, +2d from entry, +1d from question)")
    print("Channel subscription: SOFT PROMO (non-blocking; start button + delayed nudge + live check)")

    try:
        await asyncio.gather(
            dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types()),
            server.serve(),
            automation_loop(bot, settings, database.session_factory, sheets),
        )
    finally:
        await bot.session.close()
        await database.close()


if __name__ == "__main__":
    asyncio.run(main())
