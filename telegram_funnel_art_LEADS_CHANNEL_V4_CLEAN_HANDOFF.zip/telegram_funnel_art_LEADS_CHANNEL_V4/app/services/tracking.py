# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import re

CODE_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def normalize_source(value: str | None) -> str:
    raw = (value or "organic").strip()
    cleaned = "".join(ch for ch in raw if ch.isascii() and (ch.isalnum() or ch in "_-"))[:64]
    return cleaned or "organic"


def validate_campaign_code(value: str) -> str:
    if not CODE_RE.fullmatch(value):
        raise ValueError("Campaign code must contain only A-Z, a-z, 0-9, _ or - and be <= 64 chars")
    return value
