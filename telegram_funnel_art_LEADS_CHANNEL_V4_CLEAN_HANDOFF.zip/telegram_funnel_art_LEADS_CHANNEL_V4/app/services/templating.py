# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from html import escape


def render_text(text: str, *, first_name: str | None = None) -> str:
    """Tiny safe template layer for editable bot copy.

    Only {name} is supported. We intentionally avoid str.format() so admin text
    cannot accidentally interpret arbitrary braces or attributes.
    """
    name = escape((first_name or "").strip() or "коллега")
    return text.replace("{name}", name)
