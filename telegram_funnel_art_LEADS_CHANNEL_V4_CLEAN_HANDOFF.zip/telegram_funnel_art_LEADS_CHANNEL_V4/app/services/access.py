# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from sqlalchemy.ext.asyncio import async_sessionmaker

from app.config import Settings
from app.db.repo import Repo


async def is_admin(user_id: int, settings: Settings, sessions: async_sessionmaker) -> bool:
    # When admins are explicitly configured, that list is authoritative.
    # This prevents an old locally claimed admin from retaining access.
    if settings.admin_ids:
        return user_id in settings.admin_ids

    async with sessions() as session:
        return await Repo(session).is_admin(user_id)


async def all_admin_ids(settings: Settings, sessions: async_sessionmaker) -> list[int]:
    if settings.admin_ids:
        return list(dict.fromkeys(settings.admin_ids))

    async with sessions() as session:
        return await Repo(session).admin_ids()
