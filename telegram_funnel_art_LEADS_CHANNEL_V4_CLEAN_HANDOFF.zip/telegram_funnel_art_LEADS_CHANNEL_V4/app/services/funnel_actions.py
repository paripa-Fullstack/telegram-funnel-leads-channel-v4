# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from html import escape

from aiogram import Bot
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.config import Settings
from app.db.repo import Repo
from app.services.analytics import Analytics
from app.services.sheets import SheetsMirror
from app.services.timefmt import fmt_moscow
from app.services.workchat import notify_work_chat

SELLING_TOUCH_KEYS = [
    "consult_offer_4h",
    "manager_alert_24h",
    "case_after_question_24h",
    # Legacy V2 keys that may still be pending after an upgrade.
    "consult_nudge_4h",
    "manager_followup_24h",
    "case_nudge_72h",
]


def _scaled_hours(settings: Settings, hours: float) -> timedelta:
    return timedelta(hours=hours * max(settings.automation_time_scale, 0.0001))


def _display_name(first_name: str | None, last_name: str | None) -> str:
    return " ".join(x for x in [first_name, last_name] if x).strip() or "—"


async def campaign_label(repo: Repo, source_code: str) -> str:
    campaign = await repo.get_campaign(source_code)
    return campaign.channel if campaign and campaign.channel else source_code or "organic"


async def record_material_click(
    *,
    telegram_id: int,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> tuple[bool, str]:
    """Record the initial materials click and start the +4h/+24h clocks.

    Returns (first_click, folder_url). Repeated opens never reset the original timers.
    """
    async with sessions() as session:
        repo = Repo(session)
        analytics = Analytics(repo, sheets)
        lead = await repo.get_lead(telegram_id)
        folder_url = await repo.get_setting(
            "materials_folder_url", settings.materials_folder_url or settings.lead_magnet_url
        )
        if not lead:
            return False, folder_url
        consent = await repo.get_consent(lead.telegram_id)
        if not Repo.privacy_allowed(consent):
            return False, folder_url

        first_click = not await repo.has_event(lead, "materials_clicked")
        if first_click:
            event = await analytics.event("materials_clicked", lead=lead, payload={"folder_url_set": bool(folder_url)})
            # Compatibility with the existing Google Sheet formulas.
            await analytics.event("lead_magnet", lead=lead, payload={"source": "final_tz_materials_click"})
            await repo.advance_stage(lead, "material")
            has_consult = await repo.has_event(lead, "consultation_requested")
            if not has_consult:
                base = event.created_at if event and event.created_at else datetime.now(timezone.utc)
                await repo.schedule_touch(lead, "consult_offer_4h", base + _scaled_hours(settings, 4))
                await repo.schedule_touch(lead, "manager_alert_24h", base + _scaled_hours(settings, 24))
            await analytics.lead_snapshot(lead)
        else:
            await analytics.event("materials_reopened", lead=lead)

        source = await campaign_label(repo, lead.source_code)
        click_at = await repo.first_event_at(lead, "materials_clicked")
        name = _display_name(lead.first_name, lead.last_name)
        username = f"@{lead.username}" if lead.username else "—"
        await session.commit()

    if first_click:
        await notify_work_chat(
            bot,
            settings,
            sessions,
            "📥 <b>Пользователь скачал материалы</b>\n"
            f"Имя: <b>{escape(name)}</b>\n"
            f"Username: {escape(username)}\n"
            f"Telegram ID: <code>{telegram_id}</code>\n"
            f"Дата и время: <b>{fmt_moscow(click_at)}</b>\n"
            f"Источник: <b>{escape(source)}</b>",
        )
    return first_click, folder_url


async def record_consultation_request(
    *,
    telegram_id: int,
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
) -> bool:
    """One common consultation branch used by every CTA in the funnel."""
    async with sessions() as session:
        repo = Repo(session)
        analytics = Analytics(repo, sheets)
        lead = await repo.get_lead(telegram_id)
        if not lead:
            return False
        consent = await repo.get_consent(lead.telegram_id)
        if not Repo.privacy_allowed(consent):
            return False

        first_request = not await repo.has_event(lead, "consultation_requested")
        if first_request:
            event = await analytics.event("consultation_requested", lead=lead, payload={"method": "common_branch"})
            await repo.advance_stage(lead, "consultation_requested")
            # Stop only repeated selling invitations. The +2 day diagnostic question remains.
            await repo.cancel_touches(lead, SELLING_TOUCH_KEYS)
            await analytics.lead_snapshot(lead)
        else:
            event = await repo.first_event(lead, "consultation_requested")

        source = await campaign_label(repo, lead.source_code)
        name = _display_name(lead.first_name, lead.last_name)
        username = f"@{lead.username}" if lead.username else "—"
        requested_at = event.created_at if event else datetime.now(timezone.utc)
        await session.commit()

    if first_request:
        await notify_work_chat(
            bot,
            settings,
            sessions,
            "🔥 <b>Заявка на консультацию</b>\n"
            f"Имя: <b>{escape(name)}</b>\n"
            f"Username: {escape(username)}\n"
            f"Telegram ID: <code>{telegram_id}</code>\n"
            f"Дата и время заявки: <b>{fmt_moscow(requested_at)}</b>\n"
            f"Источник: <b>{escape(source)}</b>",
        )
    return True
