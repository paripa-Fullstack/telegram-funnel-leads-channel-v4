# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.config import Settings
from app.db.models import LeadConsent, ScheduledTouch
from app.db.repo import Repo
from app.services.timefmt import as_utc


async def migrate_final_tz(settings: Settings, sessions: async_sessionmaker) -> None:
    """Idempotent upgrade from the previous WOW V2 release.

    - Retires the old 48h/72h timers whose reference point did not match the final TZ.
    - Recreates the +2 day question from the original bot-entry time for consented leads.
    - Reuses a previously saved video-note and legal link when possible.
    """
    async with sessions() as session:
        repo = Repo(session)

        # Reuse old settings without overriding anything explicitly configured for FINAL TZ.
        if not await repo.get_setting("privacy_policy_url", ""):
            old = await repo.get_setting("legal_docs_url", settings.legal_docs_url)
            if old:
                await repo.set_setting("privacy_policy_url", old)
        if not await repo.get_setting("materials_folder_url", ""):
            old = settings.materials_folder_url or settings.lead_magnet_url
            if old:
                await repo.set_setting("materials_folder_url", old)
        if not await repo.get_setting("welcome_video_note_file_id", ""):
            if await repo.get_setting("welcome_media_kind", "") == "video_note":
                old_file = await repo.get_setting("welcome_media_file_id", "")
                if old_file:
                    await repo.set_setting("welcome_video_note_file_id", old_file)

        # Old timers based on consent time are not exact enough for the final TZ.
        await session.execute(
            update(ScheduledTouch)
            .where(
                ScheduledTouch.key.in_(["pain_nudge_48h", "case_nudge_72h"]),
                ScheduledTouch.status == "pending",
            )
            .values(status="canceled")
        )

        consented = await session.scalars(
            select(LeadConsent).where(LeadConsent.privacy_accepted_at.is_not(None))
        )
        for consent in consented:
            lead = await repo.get_lead_by_id(consent.lead_id)
            if not lead:
                continue
            if await repo.has_event(lead, "problem_question_48h_sent"):
                continue
            if await repo.has_event(lead, "problem_answered"):
                continue
            due = as_utc(lead.created_at) + timedelta(
                hours=48 * max(settings.automation_time_scale, 0.0001)
            )
            await repo.schedule_touch(lead, "problem_question_48h", due)

        await session.commit()
