# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from urllib.parse import urlparse

from app.config import Settings
from app.db.repo import Repo


def _valid_url(value: str) -> bool:
    try:
        parsed = urlparse((value or "").strip())
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)
    except Exception:
        return False


def channel_from_url(url: str) -> str:
    """Best-effort @username extraction for ordinary t.me public links."""
    try:
        parsed = urlparse((url or "").strip())
        host = parsed.netloc.lower().split(":", 1)[0]
        if host not in {"t.me", "telegram.me", "www.t.me", "www.telegram.me"}:
            return ""
        slug = parsed.path.strip("/").split("/", 1)[0]
        if not slug or slug.startswith("+") or slug in {"joinchat", "c"}:
            return ""
        return "@" + slug.lstrip("@")
    except Exception:
        return ""


async def resolve_promo_channel(repo: Repo, settings: Settings) -> tuple[str, str]:
    """Return (chat identifier for getChatMember, public URL for buttons).

    The current production .env already contains REQUIRED_CHANNEL/REQUIRED_CHANNEL_URL,
    so V4 reuses them automatically and also lets the admin override the public URL in DB.
    """
    db_url = (await repo.get_setting("community_channel_url", settings.community_channel_url)).strip()
    url = db_url or (settings.required_channel_url or "").strip()
    if url and not _valid_url(url):
        url = ""

    channel = channel_from_url(url)
    if not channel:
        channel = (settings.required_channel or "").strip()

    if not url and channel.startswith("@"):
        url = f"https://t.me/{channel[1:]}"
    return channel, url


async def nudge_minutes(repo: Repo, settings: Settings) -> int:
    raw = (await repo.get_setting("subscription_nudge_minutes", str(settings.subscription_nudge_minutes))).strip()
    try:
        value = int(raw)
    except Exception:
        value = settings.subscription_nudge_minutes
    return max(0, min(value, 10080))
