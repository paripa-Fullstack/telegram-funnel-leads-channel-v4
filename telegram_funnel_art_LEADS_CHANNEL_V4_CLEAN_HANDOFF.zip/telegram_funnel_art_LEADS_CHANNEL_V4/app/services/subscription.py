# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import asyncio
from dataclasses import dataclass

from aiogram import Bot
from aiogram.enums import ChatMemberStatus


@dataclass(frozen=True)
class SubscriptionCheck:
    subscribed: bool
    status: str
    error: str | None = None
    bot_status: str | None = None


def _status_value(value: object) -> str:
    raw = getattr(value, "value", value)
    return str(raw).lower()


async def diagnose_channel_access(bot: Bot, channel: str) -> SubscriptionCheck:
    """Check whether the bot itself can reliably inspect channel membership."""
    try:
        me = await bot.get_me()
        member = await bot.get_chat_member(chat_id=channel, user_id=me.id)
        status = _status_value(member.status)
        is_admin = status in {"creator", "administrator"}
        return SubscriptionCheck(
            subscribed=is_admin,
            status="ready" if is_admin else "bot_not_admin",
            bot_status=status,
            error=None if is_admin else "Bot must be an administrator of the required channel",
        )
    except Exception as exc:
        return SubscriptionCheck(
            subscribed=False,
            status="channel_error",
            bot_status=None,
            error=f"{type(exc).__name__}: {exc}",
        )


async def check_channel_subscription(
    bot: Bot,
    user_id: int,
    channel: str,
    *,
    retries: int = 2,
    retry_delay: float = 0.9,
) -> SubscriptionCheck:
    """Reliably check a user's membership and return diagnostics instead of masking API errors."""
    last_error: str | None = None

    for attempt in range(max(1, retries)):
        try:
            member = await bot.get_chat_member(chat_id=channel, user_id=user_id)
            status = _status_value(member.status)

            if status in {"creator", "administrator", "member"}:
                return SubscriptionCheck(True, status)

            if status == "restricted":
                is_member = bool(getattr(member, "is_member", False))
                return SubscriptionCheck(is_member, status)

            # Telegram currently uses left / kicked (banned in some SDK naming) for non-members.
            if status in {"left", "kicked", "banned"}:
                return SubscriptionCheck(False, status)

            return SubscriptionCheck(False, status)
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {exc}"
            if attempt + 1 < max(1, retries):
                await asyncio.sleep(retry_delay)

    bot_diag = await diagnose_channel_access(bot, channel)
    error = last_error or bot_diag.error or "Unknown Telegram API error"
    status = "bot_not_admin" if bot_diag.status == "bot_not_admin" else "api_error"
    print(f"[subscription] check failed for user={user_id} channel={channel}: {error}; bot_status={bot_diag.bot_status}")
    return SubscriptionCheck(False, status, error=error, bot_status=bot_diag.bot_status)


async def is_channel_member(bot: Bot, user_id: int, channel: str) -> bool:
    """Compatibility wrapper for old callers."""
    return (await check_channel_subscription(bot, user_id, channel)).subscribed
