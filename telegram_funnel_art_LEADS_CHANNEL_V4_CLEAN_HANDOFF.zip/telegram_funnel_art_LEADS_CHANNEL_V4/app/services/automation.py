# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import asyncio
from datetime import timedelta
from html import escape

from aiogram import Bot
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.bot import texts
from app.bot.keyboards import consult_keyboard, pain_keyboard, subscription_keyboard
from app.config import Settings
from app.db.repo import Repo, utcnow
from app.services.analytics import Analytics
from app.services.funnel_actions import campaign_label
from app.services.channel_promo import resolve_promo_channel
from app.services.subscription import check_channel_subscription
from app.services.sheets import SheetsMirror
from app.services.timefmt import fmt_moscow
from app.services.workchat import notify_work_chat


def _enabled(value: str) -> bool:
    return str(value).strip().lower() not in {"0", "false", "off", "нет", "no"}


def _display_name(first_name: str | None, last_name: str | None) -> str:
    return " ".join(x for x in [first_name, last_name] if x).strip() or "—"


async def process_due_touches(
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
    *,
    limit: int = 50,
) -> int:
    processed = 0
    async with sessions() as session:
        repo = Repo(session)
        # Kept as an emergency kill switch, but the final admin UI does not expose it.
        if not _enabled(await repo.get_setting("automation_enabled", "1")):
            return 0

        touches = await repo.due_touches(limit=limit)
        for touch in touches:
            lead = await repo.get_lead_by_id(touch.lead_id)
            if not lead:
                await repo.mark_touch_canceled(touch)
                continue

            consent = await repo.get_consent(lead.telegram_id)
            if not Repo.privacy_allowed(consent):
                # The final chain can only run after PD consent.
                touch.due_at = utcnow() + timedelta(hours=1)
                touch.last_error = "waiting_for_privacy_consent"
                continue

            analytics = Analytics(repo, sheets)
            has_consult = await repo.has_event(lead, "consultation_requested")
            consult_label = await repo.get_setting("btn_consult_label", "Записаться на консультацию")

            try:
                if touch.key == "channel_subscription_nudge":
                    channel, channel_url = await resolve_promo_channel(repo, settings)
                    if not channel or not channel_url:
                        await repo.mark_touch_canceled(touch)
                        continue
                    if await repo.has_event(lead, "subscription_verified"):
                        await repo.mark_touch_canceled(touch)
                        continue
                    check = await check_channel_subscription(bot, lead.telegram_id, channel, retries=1)
                    if check.subscribed:
                        await analytics.event("subscription_verified", lead=lead, payload={"channel": channel, "auto": True})
                        await analytics.lead_snapshot(lead)
                    elif check.status in {"bot_not_admin", "api_error", "channel_error"}:
                        # Temporary Telegram/API problem: retry later rather than falsely nagging.
                        touch.due_at = utcnow() + timedelta(hours=1)
                        touch.last_error = check.error or check.status
                        continue
                    else:
                        copy = await repo.get_text(
                            "subscription_nudge",
                            "Кстати, у нас есть рабочий канал про найм и управление командой. "
                            "Там регулярно выходят практические разборы и материалы — присоединяйтесь 👇",
                        )
                        subscribe_label = await repo.get_setting("btn_channel_label", "📣 Подписаться на канал")
                        check_label = await repo.get_setting("btn_channel_check_label", "✅ Проверить подписку")
                        await bot.send_message(
                            lead.telegram_id,
                            copy,
                            reply_markup=subscription_keyboard(
                                channel_url, subscribe_label=subscribe_label, check_label=check_label
                            ),
                        )
                        await analytics.event("subscription_nudge_sent", lead=lead, payload={"channel": channel})

                elif touch.key in {"problem_question_48h"}:
                    # This diagnostic question is not a repeated consultation offer and therefore
                    # still goes out even when a consultation request already exists.
                    if await repo.has_event(lead, "problem_answered"):
                        await repo.mark_touch_canceled(touch)
                        continue
                    problem_question = await repo.get_text("problem_question", texts.PROBLEM_QUESTION)
                    problem_options = {
                        key: await repo.get_setting("problem_label_" + key, label)
                        for key, label in texts.PROBLEM_OPTIONS.items()
                    }
                    await bot.send_message(
                        lead.telegram_id,
                        problem_question,
                        reply_markup=pain_keyboard(problem_options),
                    )
                    question_event = await analytics.event("problem_question_48h_sent", lead=lead)
                    await analytics.event("followup_pain_sent", lead=lead, payload={"final_tz": True})
                    # Exact TZ: case timer starts from the moment this question is actually sent.
                    await repo.schedule_touch(
                        lead,
                        "case_after_question_24h",
                        question_event.created_at + timedelta(hours=24 * max(settings.automation_time_scale, 0.0001)),
                    )

                elif touch.key in {"consult_offer_4h", "consult_nudge_4h"}:
                    if has_consult:
                        await repo.mark_touch_canceled(touch)
                        continue
                    consult_offer = await repo.get_text("consult_offer_4h", texts.CONSULT_OFFER_4H)
                    await bot.send_message(
                        lead.telegram_id,
                        consult_offer,
                        reply_markup=consult_keyboard(label=consult_label),
                    )
                    await analytics.event("consult_offer_4h_sent", lead=lead)
                    await analytics.event("followup_consult_sent", lead=lead, payload={"final_tz": True})

                elif touch.key in {"manager_alert_24h", "manager_followup_24h"}:
                    if has_consult:
                        await repo.mark_touch_canceled(touch)
                        continue
                    clicked_at = await repo.first_event_at(lead, "materials_clicked")
                    if clicked_at is None:
                        clicked_at = await repo.first_event_at(lead, "lead_magnet")
                    source = await campaign_label(repo, lead.source_code)
                    name = _display_name(lead.first_name, lead.last_name)
                    username = f"@{lead.username}" if lead.username else "—"
                    await notify_work_chat(
                        bot,
                        settings,
                        sessions,
                        "⏰ <b>24 часа после скачивания материалов — записи на консультацию нет</b>\n"
                        f"Имя: <b>{escape(name)}</b>\n"
                        f"Username: {escape(username)}\n"
                        f"Telegram ID: <code>{lead.telegram_id}</code>\n"
                        f"Материалы скачаны: <b>{fmt_moscow(clicked_at)}</b>\n"
                        f"Источник: <b>{escape(source)}</b>",
                    )
                    await analytics.event("materials_24h_no_consult_notified", lead=lead)
                    await analytics.event("manager_followup_due", lead=lead, payload={"final_tz": True})

                elif touch.key in {"case_after_question_24h", "case_nudge_72h"}:
                    if has_consult:
                        await repo.mark_touch_canceled(touch)
                        continue
                    case_text = (await repo.get_setting("case_text", texts.CASE_DEFAULT)).strip()
                    if not case_text:
                        # The TZ says the case copy will be supplied separately. Never invent it.
                        touch.due_at = utcnow() + timedelta(hours=1)
                        touch.last_error = "case_text_not_configured"
                        continue
                    await bot.send_message(
                        lead.telegram_id,
                        case_text,
                        reply_markup=consult_keyboard(label=consult_label),
                    )
                    await analytics.event("case_24h_after_question_sent", lead=lead)
                    await analytics.event("followup_case_sent", lead=lead, payload={"final_tz": True})

                elif touch.key in {"pain_nudge_48h"}:
                    # Old V2 timer used consent-time, not entry-time. It is intentionally retired.
                    await repo.mark_touch_canceled(touch)
                    continue

                else:
                    await repo.mark_touch_canceled(touch)
                    continue

                await repo.mark_touch_sent(touch)
                processed += 1
            except Exception as exc:
                await repo.mark_touch_failed(touch, f"{type(exc).__name__}: {exc}")
                print(f"[automation] {touch.key} lead={lead.telegram_id}: {type(exc).__name__}: {exc}")

        await session.commit()
    return processed


async def automation_loop(
    bot: Bot,
    settings: Settings,
    sessions: async_sessionmaker,
    sheets: SheetsMirror,
    interval_seconds: int = 30,
) -> None:
    await asyncio.sleep(3)
    while True:
        try:
            await process_due_touches(bot, settings, sessions, sheets)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"[automation loop] {type(exc).__name__}: {exc}")
        await asyncio.sleep(interval_seconds)
