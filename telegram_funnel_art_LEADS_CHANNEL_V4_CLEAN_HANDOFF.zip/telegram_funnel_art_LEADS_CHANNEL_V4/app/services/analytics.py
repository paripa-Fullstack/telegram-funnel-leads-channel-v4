# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

from typing import Any

from app.db.models import Event, Lead
from app.db.repo import Repo
from app.services.sheets import SheetsMirror


class Analytics:
    def __init__(self, repo: Repo, sheets: SheetsMirror):
        self.repo = repo
        self.sheets = sheets

    async def event(
        self,
        name: str,
        *,
        lead: Lead | None = None,
        telegram_id: int | None = None,
        source_code: str = "organic",
        payload: dict[str, Any] | None = None,
    ) -> Event:
        actual_source = lead.source_code if lead else source_code
        event = await self.repo.add_event(
            name=name,
            lead=lead,
            telegram_id=telegram_id,
            source_code=actual_source,
            payload=payload,
        )
        campaign = await self.repo.get_campaign(actual_source)
        await self.sheets.append_event(event, campaign)
        return event

    async def lead_snapshot(self, lead: Lead) -> None:
        campaign = await self.repo.get_campaign(lead.source_code)
        material_title = "Папка с полезными материалами" if await self.repo.has_event(lead, "materials_clicked") else ""
        consent = await self.repo.get_consent(lead.telegram_id)
        await self.sheets.append_lead_snapshot(
            lead,
            campaign,
            material_title,
            subscription_verified=Repo.privacy_allowed(consent),
        )
