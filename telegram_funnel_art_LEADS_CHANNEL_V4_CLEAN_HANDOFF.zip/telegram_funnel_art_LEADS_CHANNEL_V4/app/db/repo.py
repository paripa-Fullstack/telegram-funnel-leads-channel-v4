# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

from sqlalchemy import delete, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import (
    Admin,
    AppSetting,
    Campaign,
    CampaignMaterial,
    ContentText,
    CustomButton,
    Event,
    Lead,
    LeadConsent,
    Material,
    ScheduledTouch,
)


STAGE_ORDER = {
    "started": 1,
    "material": 2,
    "qualified": 3,
    "contacted": 4,
    "consultation_requested": 5,
    "consultation": 6,
    "deal": 7,
    "lost": 99,
}

TERMINAL_STAGES = {"consultation_requested", "consultation", "deal", "lost"}
MAX_ACTIVE_MATERIALS = 6


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Repo:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def is_admin(self, telegram_id: int) -> bool:
        return bool(await self.session.scalar(select(Admin.id).where(Admin.telegram_id == telegram_id)))

    async def admin_ids(self) -> list[int]:
        result = await self.session.scalars(select(Admin.telegram_id).order_by(Admin.created_at.asc()))
        return list(result)

    async def claim_first_admin(self, *, telegram_id: int, username: str | None,
                                first_name: str | None) -> bool:
        existing = int(await self.session.scalar(select(func.count()).select_from(Admin)) or 0)
        if existing:
            return False
        self.session.add(Admin(telegram_id=telegram_id, username=username, first_name=first_name))
        await self.session.flush()
        return True

    async def get_lead(self, telegram_id: int) -> Lead | None:
        return await self.session.scalar(select(Lead).where(Lead.telegram_id == telegram_id))

    async def get_lead_by_id(self, lead_id: int) -> Lead | None:
        return await self.session.get(Lead, lead_id)

    async def upsert_lead(self, *, telegram_id: int, username: str | None, first_name: str | None,
                          last_name: str | None, source_code: str) -> tuple[Lead, bool]:
        lead = await self.get_lead(telegram_id)
        created = lead is None
        if lead is None:
            lead = Lead(
                telegram_id=telegram_id,
                username=username,
                first_name=first_name,
                last_name=last_name,
                source_code=source_code or "organic",
                stage="started",
            )
            self.session.add(lead)
        else:
            lead.username = username
            lead.first_name = first_name
            lead.last_name = last_name
            # First-touch attribution: never overwrite the original source.
            if not lead.source_code:
                lead.source_code = source_code or "organic"
        await self.session.flush()
        return lead, created

    async def add_event(self, *, name: str, source_code: str = "organic", lead: Lead | None = None,
                        telegram_id: int | None = None, payload: dict[str, Any] | None = None) -> Event:
        event = Event(
            lead_id=lead.id if lead else None,
            telegram_id=telegram_id or (lead.telegram_id if lead else None),
            name=name,
            source_code=source_code or (lead.source_code if lead else "organic"),
            payload=json.dumps(payload, ensure_ascii=False) if payload else None,
        )
        self.session.add(event)
        await self.session.flush()
        return event

    async def advance_stage(self, lead: Lead, stage: str) -> Lead:
        if stage == "lost" or STAGE_ORDER.get(stage, 0) >= STAGE_ORDER.get(lead.stage, 0):
            lead.stage = stage
        await self.session.flush()
        return lead

    async def set_pain(self, lead: Lead, pain: str) -> Lead:
        lead.pain = pain
        await self.advance_stage(lead, "qualified")
        return lead

    # ---- Consent -------------------------------------------------------
    async def get_consent(self, telegram_id: int) -> LeadConsent | None:
        return await self.session.scalar(select(LeadConsent).where(LeadConsent.telegram_id == telegram_id))

    async def accept_privacy(self, lead: Lead, *, version: str = "2026-09-05") -> LeadConsent:
        """Final TZ: record only consent to personal-data processing."""
        item = await self.get_consent(lead.telegram_id)
        now = utcnow()
        if item is None:
            item = LeadConsent(lead_id=lead.id, telegram_id=lead.telegram_id)
            self.session.add(item)
        item.privacy_accepted_at = item.privacy_accepted_at or now
        item.declined_at = None
        item.version = version
        await self.session.flush()
        return item

    async def accept_consents(self, lead: Lead, *, version: str = "2026-09-01") -> LeadConsent:
        item = await self.get_consent(lead.telegram_id)
        now = utcnow()
        if item is None:
            item = LeadConsent(lead_id=lead.id, telegram_id=lead.telegram_id)
            self.session.add(item)
        item.privacy_accepted_at = item.privacy_accepted_at or now
        item.marketing_accepted_at = now
        item.marketing_revoked_at = None
        item.declined_at = None
        item.version = version
        await self.session.flush()
        return item

    async def decline_consents(self, lead: Lead, *, version: str = "2026-09-01") -> LeadConsent:
        item = await self.get_consent(lead.telegram_id)
        if item is None:
            item = LeadConsent(lead_id=lead.id, telegram_id=lead.telegram_id)
            self.session.add(item)
        item.declined_at = utcnow()
        item.version = version
        await self.session.flush()
        return item

    async def revoke_marketing(self, lead: Lead) -> LeadConsent:
        item = await self.get_consent(lead.telegram_id)
        if item is None:
            item = LeadConsent(lead_id=lead.id, telegram_id=lead.telegram_id)
            self.session.add(item)
        item.marketing_revoked_at = utcnow()
        await self.session.flush()
        return item

    async def restore_marketing(self, lead: Lead, *, version: str = "2026-09-01") -> LeadConsent:
        item = await self.get_consent(lead.telegram_id)
        if item is None:
            return await self.accept_consents(lead, version=version)
        item.marketing_accepted_at = utcnow()
        item.marketing_revoked_at = None
        item.version = version
        await self.session.flush()
        return item

    @staticmethod
    def privacy_allowed(consent: LeadConsent | None) -> bool:
        return bool(consent and consent.privacy_accepted_at)

    @staticmethod
    def marketing_allowed(consent: LeadConsent | None) -> bool:
        return bool(consent and consent.privacy_accepted_at and consent.marketing_accepted_at and not consent.marketing_revoked_at)

    # ---- Campaigns -----------------------------------------------------
    async def get_campaign(self, code: str) -> Campaign | None:
        return await self.session.scalar(select(Campaign).where(Campaign.code == code))

    async def get_campaign_by_id(self, campaign_id: int) -> Campaign | None:
        return await self.session.get(Campaign, campaign_id)

    async def save_campaign(self, *, code: str, utm_source: str = "", utm_medium: str = "",
                            utm_campaign: str = "", utm_content: str = "", channel: str = "") -> Campaign:
        item = await self.get_campaign(code)
        if item is None:
            item = Campaign(code=code)
            self.session.add(item)
        item.utm_source = utm_source or None
        item.utm_medium = utm_medium or None
        item.utm_campaign = utm_campaign or None
        item.utm_content = utm_content or None
        item.channel = channel or None
        await self.session.flush()
        return item

    async def campaigns(self, limit: int = 30) -> list[Campaign]:
        rows = await self.session.scalars(select(Campaign).order_by(Campaign.created_at.desc()).limit(limit))
        return list(rows)

    async def delete_campaign(self, campaign_id: int) -> Campaign | None:
        item = await self.get_campaign_by_id(campaign_id)
        if item is None:
            return None
        await self.session.execute(delete(CampaignMaterial).where(CampaignMaterial.campaign_code == item.code))
        await self.session.delete(item)
        await self.session.flush()
        return item

    async def campaign_material(self, campaign_code: str) -> Material | None:
        material_id = await self.session.scalar(
            select(CampaignMaterial.material_id).where(CampaignMaterial.campaign_code == campaign_code)
        )
        if not material_id:
            return None
        item = await self.get_material(int(material_id))
        return item if item and item.is_active else None

    async def set_campaign_material(self, campaign_code: str, material_id: int | None) -> None:
        mapping = await self.session.scalar(select(CampaignMaterial).where(CampaignMaterial.campaign_code == campaign_code))
        if material_id is None:
            if mapping:
                await self.session.delete(mapping)
                await self.session.flush()
            return
        if mapping is None:
            mapping = CampaignMaterial(campaign_code=campaign_code, material_id=material_id)
            self.session.add(mapping)
        else:
            mapping.material_id = material_id
        await self.session.flush()

    # ---- Materials -----------------------------------------------------
    async def active_material_count(self) -> int:
        return int(await self.session.scalar(
            select(func.count()).select_from(Material).where(Material.is_active.is_(True))
        ) or 0)

    async def create_material(self, *, title: str, description: str = "", kind: str = "none",
                              url: str = "", telegram_file_id: str = "", file_name: str = "",
                              button_text: str = "📘 Открыть материал", active: bool = True) -> Material:
        if active and await self.active_material_count() >= MAX_ACTIVE_MATERIALS:
            raise ValueError(f"Можно держать активными не больше {MAX_ACTIVE_MATERIALS} материалов")
        has_primary = bool(await self.session.scalar(
            select(Material.id).where(Material.is_primary.is_(True), Material.is_active.is_(True)).limit(1)
        ))
        item = Material(
            title=title.strip(),
            description=description.strip() or None,
            kind=kind,
            url=url.strip() or None,
            telegram_file_id=telegram_file_id or None,
            file_name=file_name or None,
            button_text=button_text.strip() or "📘 Открыть материал",
            is_active=active,
            is_primary=active and not has_primary,
        )
        self.session.add(item)
        await self.session.flush()
        return item

    async def materials(self, active_only: bool = False) -> list[Material]:
        stmt = select(Material)
        if active_only:
            stmt = stmt.where(Material.is_active.is_(True))
        rows = await self.session.scalars(
            stmt.order_by(Material.is_primary.desc(), Material.created_at.asc(), Material.id.asc())
        )
        return list(rows)

    async def material_pack(self, campaign_code: str = "organic", limit: int = MAX_ACTIVE_MATERIALS) -> list[Material]:
        active = await self.materials(active_only=True)
        priority = await self.campaign_material(campaign_code)
        ordered: list[Material] = []
        if priority:
            ordered.append(priority)
        ordered.extend(item for item in active if not priority or item.id != priority.id)
        return ordered[:limit]

    async def get_material(self, material_id: int) -> Material | None:
        return await self.session.get(Material, material_id)

    async def primary_material(self) -> Material | None:
        items = await self.materials(active_only=True)
        return items[0] if items else None

    async def set_primary_material(self, material_id: int) -> Material | None:
        item = await self.get_material(material_id)
        if not item:
            return None
        if not item.is_active and await self.active_material_count() >= MAX_ACTIVE_MATERIALS:
            raise ValueError(f"Можно держать активными не больше {MAX_ACTIVE_MATERIALS} материалов")
        await self.session.execute(update(Material).values(is_primary=False))
        item.is_primary = True
        item.is_active = True
        await self.session.flush()
        return item

    async def toggle_material(self, material_id: int) -> Material | None:
        item = await self.get_material(material_id)
        if not item:
            return None
        if not item.is_active and await self.active_material_count() >= MAX_ACTIVE_MATERIALS:
            raise ValueError(f"Можно держать активными не больше {MAX_ACTIVE_MATERIALS} материалов")
        item.is_active = not item.is_active
        if not item.is_active:
            item.is_primary = False
        await self.session.flush()
        return item

    async def delete_material(self, material_id: int) -> bool:
        item = await self.get_material(material_id)
        if not item:
            return False
        await self.session.delete(item)
        await self.session.flush()
        return True

    # ---- Custom buttons ------------------------------------------------
    async def create_button(self, *, screen: str, label: str, url: str, sort_order: int = 100) -> CustomButton:
        item = CustomButton(screen=screen, label=label.strip(), url=url.strip(), sort_order=sort_order, is_active=True)
        self.session.add(item)
        await self.session.flush()
        return item

    async def buttons(self, screen: str | None = None, active_only: bool = False) -> list[CustomButton]:
        stmt = select(CustomButton)
        if screen:
            stmt = stmt.where(CustomButton.screen == screen)
        if active_only:
            stmt = stmt.where(CustomButton.is_active.is_(True))
        rows = await self.session.scalars(
            stmt.order_by(CustomButton.screen.asc(), CustomButton.sort_order.asc(), CustomButton.id.asc())
        )
        return list(rows)

    async def get_button(self, button_id: int) -> CustomButton | None:
        return await self.session.get(CustomButton, button_id)

    async def toggle_button(self, button_id: int) -> CustomButton | None:
        item = await self.get_button(button_id)
        if not item:
            return None
        item.is_active = not item.is_active
        await self.session.flush()
        return item

    async def delete_button(self, button_id: int) -> bool:
        item = await self.get_button(button_id)
        if not item:
            return False
        await self.session.delete(item)
        await self.session.flush()
        return True

    # ---- Editable texts & settings ------------------------------------
    async def get_text(self, key: str, default: str = "") -> str:
        value = await self.session.scalar(select(ContentText.value).where(ContentText.key == key))
        return value if value is not None else default

    async def set_text(self, key: str, value: str) -> None:
        item = await self.session.get(ContentText, key)
        if item is None:
            self.session.add(ContentText(key=key, value=value))
        else:
            item.value = value
        await self.session.flush()

    async def get_setting(self, key: str, default: str = "") -> str:
        value = await self.session.scalar(select(AppSetting.value).where(AppSetting.key == key))
        return value if value is not None else default

    async def set_setting(self, key: str, value: str) -> None:
        item = await self.session.get(AppSetting, key)
        if item is None:
            self.session.add(AppSetting(key=key, value=value))
        else:
            item.value = value
        await self.session.flush()

    # ---- Persistent automations ---------------------------------------
    async def schedule_touch(self, lead: Lead, key: str, due_at: datetime) -> ScheduledTouch:
        item = await self.session.scalar(
            select(ScheduledTouch).where(ScheduledTouch.lead_id == lead.id, ScheduledTouch.key == key)
        )
        if item is None:
            item = ScheduledTouch(lead_id=lead.id, telegram_id=lead.telegram_id, key=key, due_at=due_at)
            self.session.add(item)
        elif item.status != "sent":
            item.due_at = due_at
            item.status = "pending"
            item.last_error = None
        await self.session.flush()
        return item

    async def due_touches(self, limit: int = 50, *, now: datetime | None = None) -> list[ScheduledTouch]:
        now = now or utcnow()
        rows = await self.session.scalars(
            select(ScheduledTouch)
            .where(ScheduledTouch.status == "pending", ScheduledTouch.due_at <= now)
            .order_by(ScheduledTouch.due_at.asc())
            .limit(limit)
        )
        return list(rows)

    async def cancel_touches(self, lead: Lead, keys: Iterable[str] | None = None) -> int:
        stmt = update(ScheduledTouch).where(
            ScheduledTouch.lead_id == lead.id,
            ScheduledTouch.status == "pending",
        )
        if keys is not None:
            stmt = stmt.where(ScheduledTouch.key.in_(list(keys)))
        result = await self.session.execute(stmt.values(status="canceled"))
        await self.session.flush()
        return int(result.rowcount or 0)

    async def mark_touch_sent(self, item: ScheduledTouch) -> None:
        item.status = "sent"
        item.sent_at = utcnow()
        item.last_error = None
        await self.session.flush()

    async def mark_touch_canceled(self, item: ScheduledTouch) -> None:
        item.status = "canceled"
        await self.session.flush()

    async def mark_touch_failed(self, item: ScheduledTouch, error: str) -> None:
        item.attempts += 1
        item.last_error = error[:2000]
        if item.attempts >= 3:
            item.status = "failed"
        else:
            item.due_at = utcnow() + timedelta(minutes=15)
        await self.session.flush()

    async def has_event(self, lead: Lead, name: str) -> bool:
        return bool(await self.session.scalar(
            select(Event.id).where(Event.lead_id == lead.id, Event.name == name).limit(1)
        ))

    async def first_event(self, lead: Lead, name: str) -> Event | None:
        return await self.session.scalar(
            select(Event)
            .where(Event.lead_id == lead.id, Event.name == name)
            .order_by(Event.created_at.asc(), Event.id.asc())
            .limit(1)
        )

    async def first_event_at(self, lead: Lead, name: str) -> datetime | None:
        item = await self.first_event(lead, name)
        return item.created_at if item else None

    # ---- Leads / analytics --------------------------------------------
    async def recent_leads(self, limit: int = 10) -> list[Lead]:
        result = await self.session.scalars(select(Lead).order_by(Lead.created_at.desc()).limit(limit))
        return list(result)

    async def stats(self) -> dict[str, int]:
        async def unique_events(*names: str) -> int:
            value = await self.session.scalar(
                select(func.count(func.distinct(Event.telegram_id))).where(
                    Event.name.in_(names), Event.telegram_id.is_not(None)
                )
            )
            return int(value or 0)

        return {
            "clicks": int(await self.session.scalar(select(func.count()).select_from(Event).where(Event.name == "click")) or 0),
            "leads": int(await self.session.scalar(select(func.count()).select_from(Lead)) or 0),
            "consented": await unique_events("consent_confirmed", "consent_accepted"),
            "material": await unique_events("materials_clicked", "lead_magnet"),
            "qualified": await unique_events("problem_answered", "qualified"),
            "consultation_requested": await unique_events("consultation_requested"),
            "consultation": await unique_events("manager_consulted"),
            "deal": await unique_events("manager_deal"),
            "lost": await unique_events("manager_lost"),
        }
