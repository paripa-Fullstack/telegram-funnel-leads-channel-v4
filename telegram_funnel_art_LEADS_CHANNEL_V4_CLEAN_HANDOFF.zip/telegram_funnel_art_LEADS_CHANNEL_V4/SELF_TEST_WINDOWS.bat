@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
python scripts\static_v3_audit.py
python scripts\test_final_tz.py
pause
