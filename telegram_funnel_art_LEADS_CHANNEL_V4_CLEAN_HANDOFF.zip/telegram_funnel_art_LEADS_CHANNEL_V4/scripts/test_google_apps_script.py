# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import requests

from app.config import get_settings


def main() -> int:
    settings = get_settings()
    url = settings.google_apps_script_url
    secret = settings.google_apps_script_secret

    print("Google Sheets / Apps Script connection test")
    print("----------------------------------------")

    if not url:
        print("FAIL: GOOGLE_APPS_SCRIPT_URL is empty")
        return 2
    if not secret:
        print("FAIL: GOOGLE_APPS_SCRIPT_SECRET is empty")
        return 2

    try:
        response = requests.get(url, timeout=settings.google_apps_script_timeout, allow_redirects=True)
        response.raise_for_status()
        data = response.json()
    except Exception as exc:
        print(f"FAIL: cannot reach Apps Script: {type(exc).__name__}: {exc}")
        return 3

    if data.get("ok") is not True:
        print(f"FAIL: endpoint answered but is not ready: {data}")
        return 4

    print(f"OK: endpoint is reachable: {data.get('service', 'Google Apps Script')}")
    print("No test rows were written. The real write test happens when a user enters the bot.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
