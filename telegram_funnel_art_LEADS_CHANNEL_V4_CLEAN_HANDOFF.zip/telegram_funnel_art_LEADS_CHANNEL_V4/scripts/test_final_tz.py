# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import asyncio
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.bot import texts
from app.config import Settings
from app.db.repo import Repo
from app.db.session import Database
from app.services.analytics import Analytics
from app.services.automation import process_due_touches
from app.services.funnel_actions import record_consultation_request, record_material_click
from app.services.material_link import make_materials_tracking_url, verify_materials_signature
from app.services.migration import migrate_final_tz
from app.services.sheets import SheetsMirror


class FakeBot:
    def __init__(self) -> None:
        self.sent: list[tuple[int | str, str, object]] = []

    async def send_message(self, chat_id, text: str, reply_markup=None):
        self.sent.append((chat_id, text, reply_markup))
        return True


async def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db = Database(f"sqlite+aiosqlite:///{Path(tmp) / 'final_tz.sqlite3'}")
        await db.init()
        settings = Settings(
            telegram_bot_token="TEST_ONLY_TOKEN",
            admin_ids=[111, 222],
            auto_claim_first_admin=False,
            public_base_url="https://example.test",
            materials_folder_url="https://drive.google.com/example",
            work_chat_id="-100999",
            automation_time_scale=1.0,
            required_channel="",
            google_apps_script_url="",
            google_apps_script_secret="",
        )
        sheets = SheetsMirror(settings)
        bot = FakeBot()

        # Signed direct materials link exists and is tamper-resistant.
        url = make_materials_tracking_url(settings, 123456)
        assert url.startswith("https://example.test/materials/123456/")
        sig = url.rsplit("/", 1)[1]
        assert verify_materials_signature(settings, 123456, sig)
        assert not verify_materials_signature(settings, 654321, sig)

        async with db.session_factory() as session:
            repo = Repo(session)
            await repo.set_setting("materials_folder_url", settings.materials_folder_url)
            await repo.set_setting("work_chat_id", settings.work_chat_id)
            lead, created = await repo.upsert_lead(
                telegram_id=123456,
                username="client",
                first_name="Иван",
                last_name="Иванов",
                source_code="tg_ad_01",
            )
            assert created
            # No final chain before PD consent.
            assert not (await repo.due_touches(now=datetime.now(timezone.utc) + timedelta(days=100)))
            consent = await repo.accept_privacy(lead)
            assert Repo.privacy_allowed(consent)
            assert consent.marketing_accepted_at is None  # final TZ does not ask for marketing consent
            await Analytics(repo, sheets).event("consent_confirmed", lead=lead)
            # Exact +2d point is based on original bot entry.
            await repo.schedule_touch(lead, "problem_question_48h", lead.created_at + timedelta(days=2))
            await session.commit()

        # First materials click records and schedules +4h/+24h. Second click never resets timers.
        first, folder = await record_material_click(
            telegram_id=123456, bot=bot, settings=settings, sessions=db.session_factory, sheets=sheets
        )
        assert first and folder == settings.materials_folder_url
        async with db.session_factory() as session:
            repo = Repo(session)
            lead = await repo.get_lead(123456)
            touches1 = {t.key: t.due_at for t in await repo.due_touches(now=datetime.now(timezone.utc) + timedelta(days=10))}
            assert "consult_offer_4h" in touches1 and "manager_alert_24h" in touches1 and "problem_question_48h" in touches1
            assert await repo.has_event(lead, "materials_clicked")
            assert await repo.has_event(lead, "lead_magnet")
        first_again, _ = await record_material_click(
            telegram_id=123456, bot=bot, settings=settings, sessions=db.session_factory, sheets=sheets
        )
        assert not first_again
        async with db.session_factory() as session:
            repo = Repo(session)
            touches2 = {t.key: t.due_at for t in await repo.due_touches(now=datetime.now(timezone.utc) + timedelta(days=10))}
            assert touches2["consult_offer_4h"] == touches1["consult_offer_4h"]
            assert touches2["manager_alert_24h"] == touches1["manager_alert_24h"]

        # One common consultation branch cancels only selling touches, not the +2d diagnostic question.
        ok = await record_consultation_request(
            telegram_id=123456, bot=bot, settings=settings, sessions=db.session_factory, sheets=sheets
        )
        assert ok
        async with db.session_factory() as session:
            repo = Repo(session)
            lead = await repo.get_lead(123456)
            pending = {t.key for t in await repo.due_touches(now=datetime.now(timezone.utc) + timedelta(days=10))}
            assert "problem_question_48h" in pending
            assert "consult_offer_4h" not in pending and "manager_alert_24h" not in pending
            assert await repo.has_event(lead, "consultation_requested")

            # Force the +2d question due now; it must still send even after consultation request.
            for t in await repo.due_touches(now=datetime.now(timezone.utc) + timedelta(days=10)):
                if t.key == "problem_question_48h":
                    t.due_at = datetime.now(timezone.utc) - timedelta(seconds=1)
            await session.commit()

        before = len(bot.sent)
        processed = await process_due_touches(bot, settings, db.session_factory, sheets)
        assert processed == 1
        new_messages = bot.sent[before:]
        assert any(chat == 123456 and text == texts.PROBLEM_QUESTION for chat, text, _ in new_messages)
        async with db.session_factory() as session:
            repo = Repo(session)
            lead = await repo.get_lead(123456)
            assert await repo.has_event(lead, "problem_question_48h_sent")
            all_due = await repo.due_touches(now=datetime.now(timezone.utc) + timedelta(days=10))
            case_touch = next(t for t in all_due if t.key == "case_after_question_24h")
            case_touch.due_at = datetime.now(timezone.utc) - timedelta(seconds=1)
            await session.commit()

        # Case is a selling CTA, so with an existing consultation it must be canceled and not sent.
        before = len(bot.sent)
        processed = await process_due_touches(bot, settings, db.session_factory, sheets)
        assert processed == 0 and len(bot.sent) == before

        # Second lead: exact +4h offer and +24h team-only notification.
        async with db.session_factory() as session:
            repo = Repo(session)
            lead2, _ = await repo.upsert_lead(
                telegram_id=777777,
                username=None,
                first_name="Ольга",
                last_name=None,
                source_code="organic",
            )
            await repo.accept_privacy(lead2)
            await repo.set_setting("case_text", "Согласованный кейс")
            await repo.set_text("consult_offer_4h", "CUSTOM OFFER +4H")
            await repo.set_text("problem_question", "CUSTOM QUESTION +2D")
            await repo.set_setting("btn_consult_label", "CUSTOM CONSULT BUTTON")
            await repo.set_setting("problem_label_find_strong", "CUSTOM PROBLEM OPTION")
            extra = await repo.create_button(screen="welcome", label="CUSTOM URL", url="https://example.com")
            assert extra.is_active
            await session.commit()
        await record_material_click(
            telegram_id=777777, bot=bot, settings=settings, sessions=db.session_factory, sheets=sheets
        )
        async with db.session_factory() as session:
            repo = Repo(session)
            for t in await repo.due_touches(now=datetime.now(timezone.utc) + timedelta(days=10)):
                if t.telegram_id == 777777 and t.key in {"consult_offer_4h", "manager_alert_24h"}:
                    t.due_at = datetime.now(timezone.utc) - timedelta(seconds=1)
            await session.commit()
        before = len(bot.sent)
        processed = await process_due_touches(bot, settings, db.session_factory, sheets)
        assert processed == 2
        new_messages = bot.sent[before:]
        assert any(chat == 777777 and text == "CUSTOM OFFER +4H" for chat, text, _ in new_messages)
        custom_offer_msg = next((m for m in new_messages if m[0] == 777777 and m[1] == "CUSTOM OFFER +4H"), None)
        assert custom_offer_msg is not None
        markup = custom_offer_msg[2]
        assert markup.inline_keyboard[0][0].text == "CUSTOM CONSULT BUTTON"
        assert any(chat == -100999 and "24 часа" in text for chat, text, _ in new_messages)
        assert not any(chat in {111, 222} for chat, _, _ in new_messages)  # no admin/MOP DMs

        # Editable admin content persists and is read from DB without code changes.
        async with db.session_factory() as session:
            repo = Repo(session)
            assert await repo.get_text("consult_offer_4h", texts.CONSULT_OFFER_4H) == "CUSTOM OFFER +4H"
            assert await repo.get_text("problem_question", texts.PROBLEM_QUESTION) == "CUSTOM QUESTION +2D"
            assert await repo.get_setting("btn_consult_label", "") == "CUSTOM CONSULT BUTTON"
            assert await repo.get_setting("problem_label_find_strong", "") == "CUSTOM PROBLEM OPTION"
            extras = await repo.buttons(screen="welcome", active_only=True)
            assert any(b.label == "CUSTOM URL" and b.url == "https://example.com" for b in extras)

        # Migration is idempotent and safe against old V2 timer keys.
        await migrate_final_tz(settings, db.session_factory)
        await migrate_final_tz(settings, db.session_factory)

        await db.close()

    print("FINAL EDITABLE V3 SELF-TEST: OK")
    print("Checked: PD gate, tracked materials, exact timers, consultation cancellation, work-chat-only notifications, editable texts/buttons/problem options, extra URL buttons, upgrade safety.")


if __name__ == "__main__":
    asyncio.run(main())
