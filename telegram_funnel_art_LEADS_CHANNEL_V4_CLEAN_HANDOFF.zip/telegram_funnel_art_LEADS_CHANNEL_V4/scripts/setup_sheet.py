# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
"""Prepare realtime analytics tabs in the configured Google Sheet."""
from __future__ import annotations

# Allow this script to be launched directly from the scripts folder on Windows.
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.config import get_settings
from app.services.sheets import SheetsMirror

EVENTS = "Бот — События"
LEADS = "Бот — Лиды"
FUNNEL = "Бот — Воронка"
SOURCES = "Бот — Источники"

EVENT_HEADERS = [[
    "Дата/время", "Event ID", "Telegram ID", "Lead ID", "Событие", "Код источника",
    "UTM source", "UTM medium", "UTM campaign", "UTM content", "Канал", "Данные",
]]
LEAD_HEADERS = [[
    "Обновлено", "Первый вход", "Lead ID", "Telegram ID", "Имя", "Username",
    "Код источника", "Канал / размещение", "UTM source", "UTM medium", "UTM campaign", "UTM content",
    "Материал", "Этап", "Боль", "Подписка",
]]
FUNNEL_DATA = [
    ["Этап", "Количество", "Конверсия от входа", "Конверсия с прошлого этапа"],
    ["Вошли в бот", f'=COUNTIF(\'{EVENTS}\'!E:E,"start")', 1, ""],
    ["Подписка подтверждена", f'=COUNTIF(\'{EVENTS}\'!E:E,"subscription_verified")', '=IFERROR(B3/B2,0)', '=IFERROR(B3/B2,0)'],
    ["Получили материал", f'=COUNTIF(\'{EVENTS}\'!E:E,"lead_magnet")', '=IFERROR(B4/B2,0)', '=IFERROR(B4/B3,0)'],
    ["Квалифицированы", f'=COUNTIF(\'{EVENTS}\'!E:E,"qualified")', '=IFERROR(B5/B2,0)', '=IFERROR(B5/B4,0)'],
    ["Запросили консультацию", f'=COUNTIF(\'{EVENTS}\'!E:E,"consultation_requested")', '=IFERROR(B6/B2,0)', '=IFERROR(B6/B5,0)'],
    ["Консультация состоялась", f'=COUNTIF(\'{EVENTS}\'!E:E,"manager_consulted")', '=IFERROR(B7/B2,0)', '=IFERROR(B7/B6,0)'],
    ["Сделка", f'=COUNTIF(\'{EVENTS}\'!E:E,"manager_deal")', '=IFERROR(B8/B2,0)', '=IFERROR(B8/B7,0)'],
]
SOURCE_HEADERS = [[
    "Код", "Канал / размещение", "UTM source", "UTM medium", "UTM campaign", "UTM content",
    "Входы", "Подписались", "Материал", "Консультации", "Сделки", "Конверсия в сделку",
]]


def ensure_sheets(service, spreadsheet_id: str) -> dict[str, int]:
    metadata = service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    existing = {item["properties"]["title"]: item["properties"]["sheetId"] for item in metadata.get("sheets", [])}
    requests = []
    for title in (LEADS, EVENTS, FUNNEL, SOURCES):
        if title not in existing:
            requests.append({"addSheet": {"properties": {"title": title}}})
    if requests:
        service.spreadsheets().batchUpdate(spreadsheetId=spreadsheet_id, body={"requests": requests}).execute()
        metadata = service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
        existing = {item["properties"]["title"]: item["properties"]["sheetId"] for item in metadata.get("sheets", [])}
    return existing


def main() -> None:
    settings = get_settings()
    mirror = SheetsMirror(settings)
    if not mirror.enabled:
        raise SystemExit("Google Sheets is not configured. Put service-account JSON in the project and set GOOGLE_CREDENTIALS_FILE.")
    service = mirror._get_service()
    ids = ensure_sheets(service, settings.google_sheet_id)

    updates = [
        (f"'{EVENTS}'!A1:L1", EVENT_HEADERS),
        (f"'{LEADS}'!A1:P1", LEAD_HEADERS),
        (f"'{FUNNEL}'!A1:D8", FUNNEL_DATA),
        (f"'{SOURCES}'!A1:L1", SOURCE_HEADERS),
    ]
    for range_name, values in updates:
        service.spreadsheets().values().update(
            spreadsheetId=settings.google_sheet_id,
            range=range_name,
            valueInputOption="USER_ENTERED",
            body={"values": values},
        ).execute()

    requests = []
    for title in (LEADS, EVENTS, FUNNEL, SOURCES):
        sheet_id = ids[title]
        requests += [
            {"updateSheetProperties": {
                "properties": {"sheetId": sheet_id, "gridProperties": {"frozenRowCount": 1}},
                "fields": "gridProperties.frozenRowCount",
            }},
            {"repeatCell": {
                "range": {"sheetId": sheet_id, "startRowIndex": 0, "endRowIndex": 1},
                "cell": {"userEnteredFormat": {
                    "backgroundColor": {"red": 0.12, "green": 0.12, "blue": 0.12},
                    "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}},
                    "horizontalAlignment": "CENTER",
                    "verticalAlignment": "MIDDLE",
                }},
                "fields": "userEnteredFormat",
            }},
            {"autoResizeDimensions": {"dimensions": {"sheetId": sheet_id, "dimension": "COLUMNS"}}},
        ]
    requests += [
        {"repeatCell": {
            "range": {"sheetId": ids[FUNNEL], "startRowIndex": 1, "endRowIndex": 50, "startColumnIndex": 2, "endColumnIndex": 4},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": "PERCENT", "pattern": "0.0%"}}},
            "fields": "userEnteredFormat.numberFormat",
        }},
        {"repeatCell": {
            "range": {"sheetId": ids[SOURCES], "startRowIndex": 1, "endRowIndex": 1000, "startColumnIndex": 11, "endColumnIndex": 12},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": "PERCENT", "pattern": "0.0%"}}},
            "fields": "userEnteredFormat.numberFormat",
        }},
    ]
    service.spreadsheets().batchUpdate(spreadsheetId=settings.google_sheet_id, body={"requests": requests}).execute()
    print("Google Sheets ready: Бот — Лиды / События / Воронка / Источники")


if __name__ == "__main__":
    main()
