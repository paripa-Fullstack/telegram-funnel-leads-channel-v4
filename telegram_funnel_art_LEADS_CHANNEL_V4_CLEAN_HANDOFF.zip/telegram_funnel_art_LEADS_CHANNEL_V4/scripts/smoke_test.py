# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

# Allow this script to be launched directly from the scripts folder on Windows.
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import asyncio

from app.db.repo import Repo
from app.db.session import Database


async def main() -> None:
    db = Database("sqlite+aiosqlite:///:memory:")
    await db.init()
    async with db.session_factory() as session:
        repo = Repo(session)
        material = await repo.create_material(
            title="Smoke Test PDF",
            description="test",
            kind="url",
            url="https://example.com/material.pdf",
        )
        campaign = await repo.save_campaign(
            code="smoke_test",
            utm_source="telegram",
            utm_medium="bot",
            utm_campaign="smoke",
            utm_content="post_1",
            channel="Smoke channel",
        )
        await repo.set_campaign_material(campaign.code, material.id)
        lead, created = await repo.upsert_lead(
            telegram_id=123456789,
            username="smoke",
            first_name="Smoke",
            last_name="Test",
            source_code=campaign.code,
        )
        assert created
        selected = await repo.campaign_material(lead.source_code)
        assert selected is not None and selected.id == material.id
        await repo.add_event(name="start", lead=lead)
        await repo.advance_stage(lead, "material")
        await repo.add_event(name="lead_magnet", lead=lead)
        await session.commit()

        stats = await repo.stats()
        assert stats["leads"] == 1
        assert stats["material"] == 1

        # Source deletion must remove the live campaign + material mapping,
        # while historical lead attribution stays intact.
        deleted = await repo.delete_campaign(campaign.id)
        assert deleted is not None and deleted.code == "smoke_test"
        assert await repo.get_campaign("smoke_test") is None
        assert await repo.campaign_material("smoke_test") is None
        persisted_lead = await repo.get_lead(123456789)
        assert persisted_lead is not None and persisted_lead.source_code == "smoke_test"
        await session.commit()

    await db.close()
    print("SMOKE TEST OK: database, attribution, source deletion and analytics core work.")


if __name__ == "__main__":
    asyncio.run(main())
