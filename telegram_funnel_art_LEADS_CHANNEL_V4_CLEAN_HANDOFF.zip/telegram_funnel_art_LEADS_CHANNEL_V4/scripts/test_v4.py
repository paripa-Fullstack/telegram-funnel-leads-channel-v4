# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path
from types import SimpleNamespace

from app.config import Settings
from app.db.session import Database
from app.db.repo import Repo
from app.services.channel_promo import resolve_promo_channel, nudge_minutes
from app.services.lead_alerts import notify_new_lead_admins


class FakeBot:
    def __init__(self):
        self.sent = []
        self.members = {}
    async def send_message(self, chat_id, text, reply_markup=None):
        self.sent.append((chat_id, text, reply_markup))
        return True
    async def get_me(self):
        return SimpleNamespace(id=999999)
    async def get_chat_member(self, chat_id, user_id):
        if user_id == 999999:
            return SimpleNamespace(status="administrator")
        status = self.members.get(user_id, "left")
        return SimpleNamespace(status=status)


async def main():
    with tempfile.TemporaryDirectory() as tmp:
        db = Database(f"sqlite+aiosqlite:///{Path(tmp) / 'v4.sqlite3'}")
        await db.init()
        settings = Settings(
            telegram_bot_token="TEST_ONLY_TOKEN",
            admin_ids=[111, 222],
            auto_claim_first_admin=False,
            required_channel="@hr_katerinaparipa",
            required_channel_url="https://t.me/hr_katerinaparipa",
            community_channel_url="",
            subscription_nudge_minutes=30,
            google_apps_script_url="",
            google_apps_script_secret="",
        )
        bot = FakeBot()
        async with db.session_factory() as session:
            repo = Repo(session)
            channel, url = await resolve_promo_channel(repo, settings)
            assert channel == "@hr_katerinaparipa"
            assert url == "https://t.me/hr_katerinaparipa"
            assert await nudge_minutes(repo, settings) == 30
            lead, created = await repo.upsert_lead(
                telegram_id=333, username="client", first_name="Иван", last_name=None, source_code="ad_01"
            )
            assert created
            await session.commit()

        sent = await notify_new_lead_admins(bot, settings, db.session_factory, lead, source_label="Тестовый канал")
        assert sent == 2
        assert {m[0] for m in bot.sent} == {111, 222}
        assert all("Новый вход в воронку" in m[1] for m in bot.sent)
        assert all("Тестовый канал" in m[1] for m in bot.sent)
        assert all(m[2].inline_keyboard[0][0].callback_data == "admin:write:333" for m in bot.sent)
        assert all(any(b.callback_data == "admin:subcheck:333" for row in m[2].inline_keyboard for b in row) for m in bot.sent)

        # DB override of the public channel remains editable without touching env/code.
        async with db.session_factory() as session:
            repo = Repo(session)
            await repo.set_setting("community_channel_url", "https://t.me/new_hr_channel")
            await repo.set_setting("subscription_nudge_minutes", "45")
            await session.commit()
        async with db.session_factory() as session:
            repo = Repo(session)
            channel, url = await resolve_promo_channel(repo, settings)
            assert channel == "@new_hr_channel" and url.endswith("/new_hr_channel")
            assert await nudge_minutes(repo, settings) == 45

        await db.close()
    print("LEADS + CHANNEL V4 SELF-TEST: OK")
    print("Checked: immediate admin DMs, admin lead-card callbacks, channel fallback/override, subscription-promo configuration.")


if __name__ == "__main__":
    asyncio.run(main())
