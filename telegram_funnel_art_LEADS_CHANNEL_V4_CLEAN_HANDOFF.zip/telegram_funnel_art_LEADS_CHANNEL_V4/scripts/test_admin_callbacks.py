# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from app.bot.keyboards import admin_lead_keyboard

uid = 123456789
kb = admin_lead_keyboard(uid)
values = [b.callback_data for row in kb.inline_keyboard for b in row]
expected = {
    f"admin:script_pain:{uid}",
    f"admin:script_consult:{uid}",
    f"admin:write:{uid}",
    f"admin:contact:{uid}",
    f"admin:consulted:{uid}",
    f"admin:deal:{uid}",
    f"admin:lost:{uid}",
}
assert set(values) == expected, (values, expected)
print("ADMIN CALLBACK TEST OK: quick scripts + write + statuses")
