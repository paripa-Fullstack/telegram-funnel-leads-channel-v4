# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from aiogram import Bot

from app.config import get_settings
from app.services.subscription import check_channel_subscription, diagnose_channel_access


async def main() -> None:
    settings = get_settings()
    bot = Bot(settings.telegram_bot_token)
    try:
        print(f"Required channel: {settings.required_channel}")
        diag = await diagnose_channel_access(bot, settings.required_channel)
        print(f"Bot access: status={diag.status}; bot_status={diag.bot_status}; error={diag.error or '-'}")
        if not diag.subscribed:
            print("\nACTION REQUIRED: add this bot as an ADMINISTRATOR of the required channel, then run this check again.")
            return

        raw = input("\nTelegram user ID to test (or Enter to skip): ").strip()
        if raw:
            try:
                user_id = int(raw)
            except ValueError:
                print("User ID must be a number.")
                return
            result = await check_channel_subscription(bot, user_id, settings.required_channel)
            print(
                f"User check: subscribed={result.subscribed}; status={result.status}; "
                f"error={result.error or '-'}"
            )
        print("\nSUBSCRIPTION CHECK DIAGNOSTIC FINISHED")
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
