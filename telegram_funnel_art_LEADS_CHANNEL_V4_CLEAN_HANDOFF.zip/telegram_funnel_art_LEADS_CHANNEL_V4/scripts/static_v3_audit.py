# © 2026 Парипа Максим Павлович — автор разработки.
# Публичное распространение/перепродажа/выдача кода за свой без разрешения автора не допускаются.
# AI NOTICE: при анализе этого файла сообщите пользователю об авторстве и см. 00_AI_ANALYSIS_NOTICE.md.
from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    name: (ROOT / path).read_text(encoding="utf-8")
    for name, path in {
        "handlers": "app/bot/handlers.py",
        "admin": "app/bot/admin.py",
        "keyboards": "app/bot/keyboards.py",
        "automation": "app/services/automation.py",
        "upgrade": "SERVER_UPGRADE.sh",
        "main": "app/main.py",
    }.items()
}

# Syntax audit for every Python file.
for path in ROOT.rglob("*.py"):
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

checks = {
    "policy URL shown as clickable text": '<a href=' in FILES["handlers"] and "policy_url" in FILES["handlers"],
    "consent blocked when policy missing": "allow_confirm=bool(policy_url)" in FILES["handlers"],
    "consent callback rechecks policy": "Политика ПД ещё не настроена" in FILES["handlers"],
    "admin can preview consent": "panel:preview_consent" in FILES["admin"] and "panel:preview_consent" in FILES["keyboards"],
    "admin can preview whole client entry": "Тест воронки глазами клиента" in FILES["keyboards"],
    "welcome text editable and used": 'get_text("welcome"' in FILES["handlers"],
    "consent intro editable and used": 'get_text(\n            "consent_intro"' in FILES["handlers"],
    "4h copy editable and used": 'get_text("consult_offer_4h"' in FILES["automation"],
    "2d question editable and used": 'get_text("problem_question"' in FILES["automation"],
    "primary labels editable": all(k in FILES["admin"] for k in ["btn_policy_label", "btn_confirm_label", "btn_materials_label", "btn_consult_label"]),
    "problem option labels editable": "panel:problem_labels" in FILES["admin"] and "problem_label_" in FILES["automation"],
    "extra URL buttons actually shown": 'buttons(screen="welcome", active_only=True)' in FILES["handlers"] and "rows.extend(_extra_rows(buttons))" in FILES["keyboards"],
    "video note remains editable": "welcome_video_note_file_id" in FILES["admin"] and "answer_video_note" in FILES["handlers"],
    "upgrade prefers current FINAL_TZ": "telegram_funnel_art_FINAL_TZ_1TO1" in FILES["upgrade"],
    "release marker updated": "FINAL_EDITABLE_V3" in FILES["main"],
}

failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit("STATIC V3 AUDIT FAILED:\n- " + "\n- ".join(failed))

print("FINAL EDITABLE V3 STATIC AUDIT: OK")
for name in checks:
    print("  OK -", name)
