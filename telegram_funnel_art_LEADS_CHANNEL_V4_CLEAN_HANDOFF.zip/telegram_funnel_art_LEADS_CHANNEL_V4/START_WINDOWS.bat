@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ========================================
echo Telegram Funnel Art - WOW FUNNEL V2
echo ========================================
echo.

REM WinRAR/7-Zip often launches only this BAT from a temporary folder.
if not exist "%~dp0requirements.txt" goto not_extracted
if not exist "%~dp0app\main.py" goto not_extracted
if not exist "%~dp0.env" goto not_extracted

where py >nul 2>nul
if not errorlevel 1 goto use_py

where python >nul 2>nul
if not errorlevel 1 goto use_python

echo [ERROR] Python was not found.
echo Install Python 3.11 or newer from python.org.
echo During installation enable: Add Python to PATH
echo.
pause
exit /b 1

:use_py
set "PY_CMD=py -3"
goto have_python

:use_python
set "PY_CMD=python"
goto have_python

:have_python
if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating local Python environment...
    %PY_CMD% -m venv .venv
    if errorlevel 1 goto failed
) else (
    echo [1/3] Local Python environment is ready.
)

if not exist ".venv\.deps_installed" (
    echo [2/3] Installing dependencies - first launch only...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    if errorlevel 1 goto failed
    ".venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
    if errorlevel 1 goto failed
    echo ready> ".venv\.deps_installed"
) else (
    echo [2/3] Dependencies are ready. Checking Windows timezone package...
    ".venv\Scripts\python.exe" -c "import tzdata" >nul 2>nul
    if errorlevel 1 (
        echo Installing missing tzdata...
        ".venv\Scripts\python.exe" -m pip install "tzdata>=2025.2"
        if errorlevel 1 goto failed
    )
)

if not exist "data" mkdir data

echo [3/3] Starting bot...
echo.
echo Keep this window open while testing the bot.
echo Stop the bot with Ctrl+C.
echo.
".venv\Scripts\python.exe" -m app.main

echo.
echo Bot process stopped.
pause
exit /b 0

:not_extracted
echo [ERROR] The project is being started from an archive or incomplete folder.
echo.
echo DO THIS:
echo 1. Close this window.
echo 2. In WinRAR click "Extract To" / "Извлечь в".
echo 3. Open the extracted folder.
echo 4. Double-click START_WINDOWS.bat there.
echo.
echo The folder must contain: requirements.txt, .env and the app folder.
echo.
pause
exit /b 2

:failed
echo.
echo ========================================
echo START FAILED
echo Copy the error above and send it to ChatGPT.
echo ========================================
pause
exit /b 1
