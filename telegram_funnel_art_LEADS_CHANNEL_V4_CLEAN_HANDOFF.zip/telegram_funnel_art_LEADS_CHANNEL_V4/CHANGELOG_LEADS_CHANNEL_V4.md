# LEADS + CHANNEL V4

- Restored immediate private DM lead card to every configured admin on the first `/start`.
- Lead card includes source, Telegram ID, current channel subscription state and action buttons.
- Added `✍️ Написать лиду` and `🔎 Проверить подписку` to the lead card.
- Added `Подписаться на канал` button on the initial consent screen and under the welcome.
- Subscription is deliberately **non-blocking**: materials/consultation remain available.
- Added a delayed soft channel nudge (default 30 minutes after PD consent) only for non-subscribers.
- Delayed nudge has `Подписаться` + `Проверить подписку` buttons and records `subscription_verified`.
- Admin can edit channel URL, channel-button label, nudge text and delay (0 disables auto nudge).
- Reuses existing `REQUIRED_CHANNEL=@hr_katerinaparipa` / channel URL automatically after upgrade.
- Existing work-chat notifications from the final TZ remain unchanged; the immediate NEW LEAD alert goes to admins privately.
