# Deploy LEADS + CHANNEL V4 on BestHost

1. Upload `telegram_funnel_art_LEADS_CHANNEL_V4.zip` by SFTP to `/opt/hrbot`.
2. Run:

```bash
cd /opt/hrbot
rm -rf telegram_funnel_art_LEADS_CHANNEL_V4
unzip telegram_funnel_art_LEADS_CHANNEL_V4.zip
cd telegram_funnel_art_LEADS_CHANNEL_V4
./SERVER_UPGRADE.sh
./SELF_TEST_SERVER.sh
docker compose ps
docker compose logs --tail=100
```

Expected release: `LEADS_CHANNEL_V4`, container `healthy`, Google Sheets READY.
The upgrade script stops only the previous HR-bot release, copies its `.env` and SQLite data, then starts V4.
