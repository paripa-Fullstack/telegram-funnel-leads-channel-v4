#!/usr/bin/env bash
set -euo pipefail
python3 scripts/static_v4_audit.py
docker compose run --rm funnel python scripts/test_final_tz.py
docker compose run --rm funnel python scripts/test_v4.py
